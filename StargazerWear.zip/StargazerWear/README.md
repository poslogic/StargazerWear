# Stargazer (Wear OS)

Live sky map for your wrist.

- **Sky screen** (home): Sun, Moon, planets, bright stars, the ISS and recent Starlink satellites, rotating with your compass heading. Tap "Red mode" for night vision.
- **Swipe up**: next visible ISS and Starlink passes, soonest first.
- **Swipe down**: settings (screen idle time, ISS 5-minute alert, flip sky 180 degrees, refresh satellites).
- **Swipe left**: Sun, Moon and planet pages with a picture plus rise, set and highest-point times.

Satellite data (TLEs) comes from CelesTrak and is cached for 12 hours, so the watch needs a Wi-Fi/phone/LTE connection now and then.
Pass times use a simplified orbit model, so expect an error of up to a minute or so.
