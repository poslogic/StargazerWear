# Stargazer Wear OS App

A stargazing companion for Wear OS showing real-time celestial positions, ISS passes, and a compass view — all on your wrist.

## Features

- 🌌 **Live Sky View** — Point your watch at the sky to see Sun, Moon, planets, bright stars, and the ISS
- 🧭 **Compass Ring** — Always-visible heading with cardinal directions
- 🔴 **Red Light Mode** — Preserves night vision for dark-sky observing
- 🛰️ **ISS Pass Predictions** — Countdown to next visible pass with altitude
- ⌚ **Complication Support** — Sun/Moon altitude, ISS countdown on any watch face
- 🎴 **Tile** — Glanceable sky summary on your tiles carousel
- 📍 **GPS Integration** — Auto-detects location for accurate sky calculations

## Building the APK

### Prerequisites
- Android Studio Ladybug (2024.2.1) or later
- Android SDK 34 (API level 34)
- Wear OS emulator or physical Wear OS 3+ device

### Steps

1. **Open in Android Studio**
   ```
   File → Open → Select the StargazerWear folder
   ```

2. **Sync Gradle**
   - Wait for Gradle sync to complete
   - Accept any SDK license prompts

3. **Build APK**
   ```
   Build → Build Bundle(s) / APK(s) → Build APK(s)
   ```

4. **Install on Watch**
   - **Emulator**: Drag the generated `app-debug.apk` onto the emulator window
   - **Physical Watch**: Enable USB debugging on watch, then:
     ```bash
     adb install app/build/outputs/apk/debug/app-debug.apk
     ```

### Debug APK Location
After build: `app/build/outputs/apk/debug/app-debug.apk`

## Project Structure

```
StargazerWear/
├── app/
│   ├── src/main/
│   │   ├── java/com/burtbot/stargazer/
│   │   │   ├── MainActivity.kt           # Main sky view + compass
│   │   │   ├── StargazerComplicationProvider.kt  # Watch face complications
│   │   │   └── StargazerTileService.kt   # Tile for tiles carousel
│   │   ├── res/
│   │   │   ├── values/strings.xml
│   │   │   ├── values/colors.xml
│   │   │   ├── values/themes.xml
│   │   │   ├── drawable/ic_launcher.xml
│   │   │   ├── mipmap-*/ic_launcher.xml
│   │   │   └── xml/tile_preview.xml
│   │   └── AndroidManifest.xml
│   ├── build.gradle.kts
│   └── proguard-rules.pro
├── build.gradle.kts
├── settings.gradle.kts
└── README.md (this file)
```

## Key Implementation Details

### Sky Calculations (MainActivity.kt)
- **Julian Date** conversion for astronomical calculations
- **Sun position** via simplified VSOP87 (mean longitude, anomaly, ecliptic longitude)
- **Moon position** via simplified ELP2000 (mean longitude, anomaly, argument of latitude)
- **Planets** — placeholder positions (real app would use VSOP87 or JPL DE440)
- **Stars** — fixed catalog of 8 brightest stars
- **ISS** — simplified pass prediction (real app would parse TLE data via SGP4)

### Coordinate Transforms
- Equatorial (RA/Dec) → Horizontal (Azimuth/Altitude) using observer lat/lon and Local Sidereal Time
- Watch compass heading (azimuth) used to rotate sky view so "up" = where you're pointing

### Red Light Mode
- Toggles entire UI to red-on-black palette
- Preserves dark adaptation for night observing

### Complication Provider
Supports 4 complication types:
- `SHORT_TEXT` — ISS countdown
- `LONG_TEXT` — Sun/Moon altitude + ISS
- `RANGED_VALUE` — ISS pass progress bar
- `SMALL_IMAGE` — App icon

### Tile Service
- Updates every 60 seconds
- Shows current time, Sun/Moon altitude, ISS countdown
- Uses ProtoLayout Material components

## Permissions Required
- `ACCESS_FINE_LOCATION` — For accurate sky calculations
- `FOREGROUND_SERVICE_LOCATION` — For background location updates (future)
- `VIBRATE` — Haptic feedback (future: ISS pass alerts)
- `WAKE_LOCK` — Keep screen on during observing (future)

## Customization Ideas

1. **Add TLE parsing** — Use `sgp4` library for real ISS predictions
2. **Deep sky objects** — Add Messier/NGC catalog with magnitude filter
3. **Haptic alerts** — Vibrate when ISS rises/culminates/sets
4. **Voice commands** — "OK Google, where's Jupiter?"
5. **Offline star catalog** — Bundle Hipparcos/TYCHO for 100k+ stars
6. **Meteor shower calendar** — Peak dates, radiant position, ZHR
7. **Astrophotography helper** — Exposure calculator, star trail simulator
8. **Social features** — Share observing logs, "wave" to other Stargazer users

## License

MIT — Built with ❤️ by Burt-Bot for vibe coding

---

**Note**: This is a functional prototype. For production use, replace simplified astronomy with a proper library (e.g., `aa-lib`, `jpl-ephemeris`, or port `skyfield` to Kotlin).