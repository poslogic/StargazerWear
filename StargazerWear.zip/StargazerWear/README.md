# Stargazer (Wear OS)

Live sky map for your wrist.

- **Sky screen** (home): Sun, Moon, planets, bright stars, the ISS and recent Starlink satellites, rotating with your compass heading. Tap "Red mode" for night vision.
- **Swipe up**: next visible ISS and Starlink passes, soonest first.
- **Swipe down**: settings (what to show: all, Sun and Moon, planets, stars or satellites; text size; screen idle time; ISS 5-minute alert; flip sky 180 degrees; refresh satellites).
- **Swipe left**: Sun, Moon and planet pages with a picture plus rise, set and highest-point times.
- **Tap** a star, planet, the Moon, the ISS or a Starlink dot on the sky map for an information card.
- **Tile**: add the "Stargazer" tile (long-press the watch face, swipe to the end of the tiles, tap +) to see the next ISS and Starlink passes.
- **Complication**: pick "ISS pass countdown" for a watch-face slot.

Satellite data (TLEs) comes from CelesTrak and is cached for 12 hours, so the watch needs a Wi-Fi/phone/LTE connection now and then.
Pass times use a simplified orbit model, so expect an error of up to a minute or so.
