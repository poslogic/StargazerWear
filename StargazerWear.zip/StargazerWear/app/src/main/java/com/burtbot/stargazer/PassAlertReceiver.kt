package com.burtbot.stargazer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class PassAlertReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        val appContext = context.applicationContext
        val action = intent.action
        Thread {
            try {
                if (action == AlertScheduler.ACTION_ALERT) {
                    showNotification(appContext)
                }
                if (action == AlertScheduler.ACTION_ALERT || action == Intent.ACTION_BOOT_COMPLETED) {
                    refreshAndReschedule(appContext)
                }
            } catch (e: Exception) {
                // nothing sensible to do in a background receiver
            } finally {
                pending.finish()
            }
        }.start()
    }

    private fun refreshAndReschedule(ctx: Context) {
        val prefs = Prefs.get(ctx)
        val lat = prefs.getString("lat", null)?.toDoubleOrNull()
        val lon = prefs.getString("lon", null)?.toDoubleOrNull()
        if (lat != null && lon != null) {
            PassRepo.recompute(ctx, lat, lon, false)
            WidgetUpdater.requestAll(ctx)
        }
        AlertScheduler.scheduleNext(ctx)
    }

    private fun showNotification(ctx: Context) {
        val start = Prefs.get(ctx).getLong("alert_pass_start", 0L)
        val pass = PassStore.load(ctx).firstOrNull { it.name == "ISS" && it.startMs == start }
        val text = if (pass != null) {
            "Max " + pass.maxEl.toInt() + "\u00B0, " + compassName(pass.startAz) + " to " + compassName(pass.endAz)
        } else {
            "Look up!"
        }

        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel("iss_alerts", "ISS pass alerts", NotificationManager.IMPORTANCE_HIGH)
        channel.enableVibration(true)
        nm.createNotificationChannel(channel)

        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(ctx, "iss_alerts")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("ISS visible in 5 min")
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(2001, n)
    }
}

fun compassName(az: Double): String {
    val names = arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
    val idx = (((az + 22.5) % 360.0) / 45.0).toInt()
    return names[idx.coerceIn(0, 7)]
}
