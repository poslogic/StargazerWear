package com.burtbot.stargazer

import android.app.PendingIntent
import android.content.Intent
import androidx.wear.watchface.complications.data.ComplicationData
import androidx.wear.watchface.complications.data.ComplicationType
import androidx.wear.watchface.complications.data.LongTextComplicationData
import androidx.wear.watchface.complications.data.PlainComplicationText
import androidx.wear.watchface.complications.data.ShortTextComplicationData
import androidx.wear.watchface.complications.datasource.ComplicationRequest
import androidx.wear.watchface.complications.datasource.SuspendingComplicationDataSourceService

/** Watch-face complication showing a countdown to the next visible ISS pass. */
class IssComplicationService : SuspendingComplicationDataSourceService() {

    override suspend fun onComplicationRequest(request: ComplicationRequest): ComplicationData? {
        val now = System.currentTimeMillis()
        val passes = PassStore.load(this).filter { it.endMs > now }
        val iss = passes.filter { it.name == "ISS" }.minByOrNull { it.startMs }
        val starlink = passes.filter { it.name == "Starlink" }.minByOrNull { it.startMs }

        return when (request.complicationType) {
            ComplicationType.SHORT_TEXT -> shortText(countdown(iss, now), "ISS")
            ComplicationType.LONG_TEXT -> {
                val first = if (iss == null) "ISS: open app" else "ISS " + dayLabel(iss.startMs, now) + " " + clock(iss.startMs)
                val second = if (starlink == null) "Starlink: --" else "Starlink " + clock(starlink.startMs)
                longText(first, second)
            }
            else -> null
        }
    }

    override fun getPreviewData(type: ComplicationType): ComplicationData? {
        return when (type) {
            ComplicationType.SHORT_TEXT -> shortText("1h23m", "ISS")
            ComplicationType.LONG_TEXT -> longText("ISS Today 21:14", "Starlink 21:20")
            else -> null
        }
    }

    private fun countdown(pass: Pass?, now: Long): String {
        if (pass == null) return "--"
        if (pass.startMs <= now) return "NOW"
        val mins = (pass.startMs - now) / 60000L
        return if (mins >= 60) "" + (mins / 60) + "h" + (mins % 60) + "m" else "" + mins + "m"
    }

    private fun tapAction(): PendingIntent {
        return PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun shortText(text: String, title: String): ComplicationData {
        return ShortTextComplicationData.Builder(
            text = PlainComplicationText.Builder(text).build(),
            contentDescription = PlainComplicationText.Builder("$title $text").build()
        )
            .setTitle(PlainComplicationText.Builder(title).build())
            .setTapAction(tapAction())
            .build()
    }

    private fun longText(text: String, title: String): ComplicationData {
        return LongTextComplicationData.Builder(
            text = PlainComplicationText.Builder(text).build(),
            contentDescription = PlainComplicationText.Builder("$text $title").build()
        )
            .setTitle(PlainComplicationText.Builder(title).build())
            .setTapAction(tapAction())
            .build()
    }
}
