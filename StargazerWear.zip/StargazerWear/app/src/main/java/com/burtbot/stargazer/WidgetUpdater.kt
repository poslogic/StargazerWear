package com.burtbot.stargazer

import android.content.ComponentName
import android.content.Context
import androidx.wear.tiles.TileService
import androidx.wear.watchface.complications.datasource.ComplicationDataSourceUpdateRequester

object WidgetUpdater {
    /** Asks the tile and the complication to redraw with the latest pass data. */
    fun requestAll(ctx: Context) {
        try {
            TileService.getUpdater(ctx).requestUpdate(IssTileService::class.java)
        } catch (e: Exception) {
            // tile not added to the carousel; nothing to update
        }
        try {
            ComplicationDataSourceUpdateRequester
                .create(ctx, ComponentName(ctx, IssComplicationService::class.java))
                .requestUpdateAll()
        } catch (e: Exception) {
            // complication not in use
        }
    }
}
