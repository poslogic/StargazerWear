package com.burtbot.stargazer

import android.content.Context
import android.content.SharedPreferences
import java.net.HttpURLConnection
import java.net.URL
import java.util.GregorianCalendar
import java.util.TimeZone
import kotlin.math.PI
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

object Prefs {
    const val NAME = "stargazer_prefs"
    fun get(ctx: Context): SharedPreferences = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
}

/** One predicted visible pass. For Starlink, several satellites close together are merged. */
data class Pass(
    val name: String,
    val startMs: Long,
    val endMs: Long,
    val maxEl: Double,
    val startAz: Double,
    val endAz: Double,
    val count: Int
)

class Tle(
    val name: String,
    val line1: String,
    val line2: String,
    val catNo: Int,
    val epochMs: Long,
    val incl: Double,
    val raan: Double,
    val ecc: Double,
    val argp: Double,
    val meanAnomaly: Double,
    val meanMotion: Double,
    val ndot: Double
)

object TleParser {
    fun parse(text: String): List<Tle> {
        val lines = text.lines().map { it.trimEnd() }.filter { it.isNotBlank() }
        val result = ArrayList<Tle>()
        var i = 0
        while (i < lines.size) {
            if (i + 2 < lines.size && lines[i + 1].startsWith("1 ") && lines[i + 2].startsWith("2 ")) {
                val t = parseSet(lines[i].trim(), lines[i + 1], lines[i + 2])
                if (t != null) result.add(t)
                i += 3
            } else if (i + 1 < lines.size && lines[i].startsWith("1 ") && lines[i + 1].startsWith("2 ")) {
                val t = parseSet("SAT", lines[i], lines[i + 1])
                if (t != null) result.add(t)
                i += 2
            } else {
                i += 1
            }
        }
        return result
    }

    private fun parseSet(name: String, l1: String, l2: String): Tle? {
        return try {
            if (l1.length < 63 || l2.length < 63) return null
            val catNo = l1.substring(2, 7).trim().toInt()
            val yy = l1.substring(18, 20).trim().toInt()
            val doy = l1.substring(20, 32).trim().toDouble()
            val ndot = l1.substring(33, 43).trim().toDoubleOrNull() ?: 0.0
            val incl = l2.substring(8, 16).trim().toDouble()
            val raan = l2.substring(17, 25).trim().toDouble()
            val ecc = ("0." + l2.substring(26, 33).trim()).toDouble()
            val argp = l2.substring(34, 42).trim().toDouble()
            val ma = l2.substring(43, 51).trim().toDouble()
            val mm = l2.substring(52, 63).trim().toDouble()
            val year = if (yy < 57) 2000 + yy else 1900 + yy
            val cal = GregorianCalendar(TimeZone.getTimeZone("UTC"))
            cal.clear()
            cal.set(year, 0, 1, 0, 0, 0)
            val epochMs = cal.timeInMillis + ((doy - 1.0) * 86400000.0).toLong()
            Tle(name, l1, l2, catNo, epochMs, incl, raan, ecc, argp, ma, mm, ndot)
        } catch (e: Exception) {
            null
        }
    }
}

/** Simple Kepler orbit with J2 secular drift. Accurate to a few km for days after the TLE epoch. */
class Orbit(val tle: Tle) {
    private val mu = 398600.4418
    private val re = 6378.137
    private val j2 = 1.08262668e-3
    private val twoPi = 2.0 * PI

    private val n0 = tle.meanMotion * twoPi / 86400.0
    private val a = (mu / (n0 * n0)).pow(1.0 / 3.0)
    private val e = tle.ecc
    private val inc = Math.toRadians(tle.incl)
    private val cosI = cos(inc)
    private val sinI = sin(inc)
    private val p = a * (1.0 - e * e)
    private val k = j2 * (re / p) * (re / p)
    private val raanDot = -1.5 * n0 * k * cosI
    private val argpDot = 0.75 * n0 * k * (5.0 * cosI * cosI - 1.0)
    private val mDot = n0 * (1.0 + 0.75 * k * sqrt(1.0 - e * e) * (3.0 * cosI * cosI - 1.0))

    /** Position in the inertial frame, kilometres. */
    fun positionEci(ms: Long): DoubleArray {
        val dt = (ms - tle.epochMs) / 1000.0
        val days = dt / 86400.0
        val raan = Math.toRadians(tle.raan) + raanDot * dt
        val argp = Math.toRadians(tle.argp) + argpDot * dt
        val m = Math.toRadians(tle.meanAnomaly) + mDot * dt + twoPi * tle.ndot * days * days
        val mm = ((m % twoPi) + twoPi) % twoPi
        var ea = mm + e * sin(mm)
        for (i in 0 until 10) {
            ea -= (ea - e * sin(ea) - mm) / (1.0 - e * cos(ea))
        }
        val xo = a * (cos(ea) - e)
        val yo = a * sqrt(1.0 - e * e) * sin(ea)
        val cO = cos(raan)
        val sO = sin(raan)
        val cw = cos(argp)
        val sw = sin(argp)
        val x = (cO * cw - sO * sw * cosI) * xo + (-cO * sw - sO * cw * cosI) * yo
        val y = (sO * cw + cO * sw * cosI) * xo + (-sO * sw + cO * cw * cosI) * yo
        val z = (sw * sinI) * xo + (cw * sinI) * yo
        return doubleArrayOf(x, y, z)
    }
}

object SkyGeo {
    private const val RE = 6378.137

    fun gmstRad(ms: Long): Double {
        val jd = ms / 86400000.0 + 2440587.5
        val d = 280.46061837 + 360.98564736629 * (jd - 2451545.0)
        val m = ((d % 360.0) + 360.0) % 360.0
        return Math.toRadians(m)
    }

    fun thetaRad(lonDeg: Double, ms: Long): Double = gmstRad(ms) + Math.toRadians(lonDeg)

    fun observerEci(latDeg: Double, theta: Double): DoubleArray {
        val lat = Math.toRadians(latDeg)
        val f = 1.0 / 298.257223563
        val e2 = f * (2.0 - f)
        val sl = sin(lat)
        val cl = cos(lat)
        val n = RE / sqrt(1.0 - e2 * sl * sl)
        return doubleArrayOf(n * cl * cos(theta), n * cl * sin(theta), n * (1.0 - e2) * sl)
    }

    /** Returns (azimuth, elevation) in degrees. */
    fun azEl(r: DoubleArray, obs: DoubleArray, theta: Double, latRad: Double): DoubleArray {
        val rx = r[0] - obs[0]
        val ry = r[1] - obs[1]
        val rz = r[2] - obs[2]
        val sl = sin(latRad)
        val cl = cos(latRad)
        val st = sin(theta)
        val ct = cos(theta)
        val south = sl * ct * rx + sl * st * ry - cl * rz
        val east = -st * rx + ct * ry
        val up = cl * ct * rx + cl * st * ry + sl * rz
        val range = sqrt(rx * rx + ry * ry + rz * rz)
        val el = asin((up / range).coerceIn(-1.0, 1.0))
        var az = atan2(east, -south)
        if (az < 0) az += 2.0 * PI
        return doubleArrayOf(Math.toDegrees(az), Math.toDegrees(el))
    }

    fun sunUnit(ms: Long): DoubleArray {
        val eq = Astro.sunEquatorial(Astro.julianDate(ms))
        val ra = Math.toRadians(eq.first)
        val dec = Math.toRadians(eq.second)
        return doubleArrayOf(cos(dec) * cos(ra), cos(dec) * sin(ra), sin(dec))
    }

    fun sunlit(r: DoubleArray, s: DoubleArray): Boolean {
        val dot = r[0] * s[0] + r[1] * s[1] + r[2] * s[2]
        if (dot >= 0.0) return true
        val px = r[0] - dot * s[0]
        val py = r[1] - dot * s[1]
        val pz = r[2] - dot * s[2]
        return sqrt(px * px + py * py + pz * pz) > RE
    }
}

object PassFinder {
    private const val MIN_EL = 10.0
    private const val STEP_MS = 30_000L

    /** Finds visible passes (sunlit satellite, dark sky, above 10 degrees) for each orbit. */
    fun find(name: String, orbits: List<Orbit>, latDeg: Double, lonDeg: Double, fromMs: Long, hours: Int): List<Pass> {
        val n = (hours * 3_600_000L / STEP_MS).toInt()
        val latRad = Math.toRadians(latDeg)
        val times = LongArray(n) { fromMs + it * STEP_MS }
        val theta = DoubleArray(n) { SkyGeo.thetaRad(lonDeg, times[it]) }
        val obs = Array(n) { SkyGeo.observerEci(latDeg, theta[it]) }
        val sun = Array(n) { SkyGeo.sunUnit(times[it]) }
        val dark = BooleanArray(n) { Astro.sunAltitude(times[it], latDeg, lonDeg) < -6.0 }

        val result = ArrayList<Pass>()
        for (orbit in orbits) {
            var inPass = false
            var anyVisible = false
            var startMs = 0L
            var endMs = 0L
            var startAz = 0.0
            var endAz = 0.0
            var maxEl = 0.0
            for (i in 0 until n) {
                val r = orbit.positionEci(times[i])
                val ae = SkyGeo.azEl(r, obs[i], theta[i], latRad)
                val el = ae[1]
                if (el > 0.0) {
                    inPass = true
                    val visible = el >= MIN_EL && dark[i] && SkyGeo.sunlit(r, sun[i])
                    if (visible) {
                        if (!anyVisible) {
                            anyVisible = true
                            startMs = times[i]
                            startAz = ae[0]
                        }
                        endMs = times[i]
                        endAz = ae[0]
                        if (el > maxEl) maxEl = el
                    }
                } else if (inPass) {
                    if (anyVisible) result.add(Pass(name, startMs, endMs, maxEl, startAz, endAz, 1))
                    inPass = false
                    anyVisible = false
                    maxEl = 0.0
                }
            }
            if (inPass && anyVisible) result.add(Pass(name, startMs, endMs, maxEl, startAz, endAz, 1))
        }
        result.sortBy { it.startMs }
        return result
    }

    /** Merges passes of many Starlink satellites that happen within ten minutes into one "train". */
    fun mergeTrains(passes: List<Pass>): List<Pass> {
        val sorted = passes.sortedBy { it.startMs }
        val out = ArrayList<Pass>()
        for (p in sorted) {
            val last = out.lastOrNull()
            if (last != null && p.startMs - last.startMs <= 10 * 60_000L) {
                out[out.size - 1] = Pass(
                    last.name,
                    last.startMs,
                    maxOf(last.endMs, p.endMs),
                    maxOf(last.maxEl, p.maxEl),
                    last.startAz,
                    last.endAz,
                    last.count + p.count
                )
            } else {
                out.add(p)
            }
        }
        return out
    }
}

object SatCache {
    @Volatile var iss: Orbit? = null
    @Volatile var starlink: List<Orbit> = emptyList()
}

object TleStore {
    private const val ISS_URL = "https://celestrak.org/NORAD/elements/gp.php?CATNR=25544&FORMAT=TLE"
    private const val STARLINK_URL = "https://celestrak.org/NORAD/elements/gp.php?GROUP=starlink&FORMAT=TLE"
    private const val MAX_AGE_MS = 12L * 3600L * 1000L
    private const val STARLINK_KEEP = 150

    private fun download(url: String): String? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 40000
            c.requestMethod = "GET"
            c.setRequestProperty("User-Agent", "StargazerWear/1.0")
            if (c.responseCode != 200) {
                c.disconnect()
                null
            } else {
                val text = c.inputStream.bufferedReader().use { it.readText() }
                c.disconnect()
                text
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun serialize(list: List<Tle>): String {
        val sb = StringBuilder()
        for (t in list) {
            sb.append(t.name).append('\n').append(t.line1).append('\n').append(t.line2).append('\n')
        }
        return sb.toString()
    }

    /** Downloads fresh element sets when the cache is old (or force is true). */
    fun refresh(ctx: Context, force: Boolean) {
        val prefs = Prefs.get(ctx)
        val age = System.currentTimeMillis() - prefs.getLong("tle_time", 0L)
        if (!force && age < MAX_AGE_MS && prefs.contains("iss_tle")) return

        var gotAny = false
        val issText = download(ISS_URL)
        if (issText != null) {
            val parsed = TleParser.parse(issText)
            if (parsed.isNotEmpty()) {
                prefs.edit().putString("iss_tle", serialize(parsed.take(1))).apply()
                gotAny = true
            }
        }
        val slText = download(STARLINK_URL)
        if (slText != null) {
            val parsed = TleParser.parse(slText).sortedByDescending { it.catNo }.take(STARLINK_KEEP)
            if (parsed.isNotEmpty()) {
                prefs.edit().putString("starlink_tle", serialize(parsed)).apply()
                gotAny = true
            }
        }
        if (gotAny) prefs.edit().putLong("tle_time", System.currentTimeMillis()).apply()
    }

    fun loadIss(ctx: Context): Tle? {
        val text = Prefs.get(ctx).getString("iss_tle", null) ?: return null
        return TleParser.parse(text).firstOrNull()
    }

    fun loadStarlink(ctx: Context): List<Tle> {
        val text = Prefs.get(ctx).getString("starlink_tle", null) ?: return emptyList()
        return TleParser.parse(text)
    }
}

object PassStore {
    fun save(ctx: Context, passes: List<Pass>) {
        val sb = StringBuilder()
        for (p in passes) {
            sb.append(p.name).append('|').append(p.startMs).append('|').append(p.endMs).append('|')
                .append(p.maxEl).append('|').append(p.startAz).append('|').append(p.endAz).append('|')
                .append(p.count).append('\n')
        }
        Prefs.get(ctx).edit().putString("passes", sb.toString()).apply()
    }

    fun load(ctx: Context): List<Pass> {
        val text = Prefs.get(ctx).getString("passes", null) ?: return emptyList()
        val out = ArrayList<Pass>()
        for (line in text.lines()) {
            val f = line.split('|')
            if (f.size < 7) continue
            try {
                out.add(Pass(f[0], f[1].toLong(), f[2].toLong(), f[3].toDouble(), f[4].toDouble(), f[5].toDouble(), f[6].toInt()))
            } catch (e: Exception) {
                // skip bad line
            }
        }
        return out
    }
}

object PassRepo {
    fun loadOrbits(ctx: Context) {
        SatCache.iss = TleStore.loadIss(ctx)?.let { Orbit(it) }
        SatCache.starlink = TleStore.loadStarlink(ctx).map { Orbit(it) }
    }

    fun recompute(ctx: Context, latDeg: Double, lonDeg: Double, withStarlink: Boolean): List<Pass> {
        val now = System.currentTimeMillis()
        if (SatCache.iss == null) loadOrbits(ctx)
        val out = ArrayList<Pass>()
        val issOrbit = SatCache.iss
        if (issOrbit != null) {
            out.addAll(PassFinder.find("ISS", listOf(issOrbit), latDeg, lonDeg, now, 72))
        }
        if (withStarlink) {
            val orbits = SatCache.starlink
            if (orbits.isNotEmpty()) {
                val raw = PassFinder.find("Starlink", orbits, latDeg, lonDeg, now, 48)
                out.addAll(PassFinder.mergeTrains(raw))
            }
        } else {
            out.addAll(PassStore.load(ctx).filter { it.name != "ISS" && it.endMs > now })
        }
        out.sortBy { it.startMs }
        PassStore.save(ctx, out)
        return out
    }
}

object SatSky {
    private const val ISS_COLOR = 0xFF2EE6FFL
    private const val STARLINK_COLOR = 0xFFFF6BFFL

    /** Current sky positions of the ISS and of the tracked Starlink satellites. */
    fun bodies(ms: Long, latDeg: Double, lonDeg: Double): List<Astro.Body> {
        val out = ArrayList<Astro.Body>()
        val theta = SkyGeo.thetaRad(lonDeg, ms)
        val obs = SkyGeo.observerEci(latDeg, theta)
        val latRad = Math.toRadians(latDeg)
        val sun = SkyGeo.sunUnit(ms)

        val iss = SatCache.iss
        if (iss != null) {
            val r = iss.positionEci(ms)
            val ae = SkyGeo.azEl(r, obs, theta, latRad)
            if (ae[1] > 0.0) out.add(Astro.Body("ISS", ae[0], ae[1], ISS_COLOR, 7f, true, "iss"))
        }
        for (o in SatCache.starlink) {
            val r = o.positionEci(ms)
            if (!SkyGeo.sunlit(r, sun)) continue
            val ae = SkyGeo.azEl(r, obs, theta, latRad)
            if (ae[1] > 0.0) out.add(Astro.Body("Starlink", ae[0], ae[1], STARLINK_COLOR, 3f, false, "starlink"))
        }
        return out
    }
}
