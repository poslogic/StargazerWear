package com.burtbot.stargazer

import android.content.Context
import androidx.wear.complications.data.ComplicationData
import androidx.wear.complications.data.ComplicationText
import androidx.wear.complications.data.SystemProviders
import androidx.wear.complications.data.TimeDependentBuilders
import androidx.wear.complications.datasource.ComplicationDataSourceService
import androidx.wear.complications.datasource.ComplicationRequest
import androidx.wear.complications.datasource.ComplicationTapListener
import androidx.wear.complications.datasource.DataSourceUpdateRequester
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asListenableFuture
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors

class StargazerComplicationProvider : ComplicationDataSourceService() {

    private val scope = CoroutineScope(Dispatchers.IO)
    private val updateRequester by lazy { DataSourceUpdateRequester.create(this) }

    override suspend fun onComplicationRequest(request: ComplicationRequest): ListenableFuture<ComplicationData> {
        return scope.asListenableFuture {
            provideComplicationData(request)
        }
    }

    private suspend fun provideComplicationData(request: ComplicationRequest): ComplicationData {
        val location = getLastKnownLocation()
        val now = Date()
        val jd = julianDate(now)
        
        // Compute next ISS pass
        val issPass = location?.let { computeIssPass(it, now) }
        
        val complicationData = when (request.complicationType) {
            ComplicationData.TYPE_SHORT_TEXT -> {
                val text = issPass?.let { "ISS in ${formatDuration(it.riseTime - System.currentTimeMillis())}" } 
                    ?: "ISS: --"
                ComplicationData.Builder(ComplicationData.TYPE_SHORT_TEXT)
                    .setShortText(ComplicationText.plainText(text))
                    .build()
            }
            ComplicationData.TYPE_LONG_TEXT -> {
                val sunAlt = sunAltitude(jd, location?.latitude ?: 0.0, location?.longitude ?: 0.0)
                val moonAlt = moonAltitude(jd, location?.latitude ?: 0.0, location?.longitude ?: 0.0)
                val text = "☀️ ${sunAlt.toInt()}°  🌙 ${moonAlt.toInt()}°\n${issPass?.let { "🛰️ ${formatDuration(it.riseTime - System.currentTimeMillis())}" } ?: "🛰️ --"}"
                ComplicationData.Builder(ComplicationData.TYPE_LONG_TEXT)
                    .setLongText(ComplicationText.plainText(text))
                    .build()
            }
            ComplicationData.TYPE_RANGED_VALUE -> {
                val issProgress = issPass?.let { 
                    (System.currentTimeMillis() - it.riseTime).toFloat() / (it.setTime - it.riseTime).toFloat()
                } ?: 0f
                ComplicationData.Builder(ComplicationData.TYPE_RANGED_VALUE)
                    .setValue(issProgress.coerceIn(0f, 1f))
                    .setMin(0f)
                    .setMax(1f)
                    .setShortText(ComplicationText.plainText("ISS Pass"))
                    .build()
            }
            ComplicationData.TYPE_SMALL_IMAGE -> {
                // Would provide a drawable resource
                ComplicationData.Builder(ComplicationData.TYPE_SMALL_IMAGE)
                    .setSmallImage(null) // TODO: add drawable
                    .setContentDescription(ComplicationText.plainText("Stargazer"))
                    .build()
            }
            else -> ComplicationData.Builder(ComplicationData.TYPE_SHORT_TEXT)
                .setShortText(ComplicationText.plainText("Stargazer"))
                .build()
        }
        return complicationData
    }

    override fun onComplicationActivated(complicationId: Int, request: ComplicationRequest) {
        super.onComplicationActivated(complicationId, request)
        updateRequester.requestUpdateAll()
    }

    private fun getLastKnownLocation(): android.location.Location? {
        // In a real app, you'd use FusedLocationProviderClient
        // For now, return null (will show defaults)
        return null
    }

    private fun julianDate(date: Date): Double = date.time / 1000.0 / 86400.0 + 2440587.5

    private fun sunAltitude(jd: Double, lat: Double, lon: Double): Float {
        val n = jd - 2451545.0
        val L = (280.460 + 0.9856474 * n) % 360
        val g = Math.toRadians((357.528 + 0.9856003 * n) % 360)
        val lambda = Math.toRadians(L + 1.915 * sin(g) + 0.020 * sin(2 * g))
        val epsilon = Math.toRadians(23.439 - 0.0000004 * n)
        val dec = asin(sin(epsilon) * sin(lambda))
        val lst = (280.46061837 + 360.98564736629 * (jd - 2451545.0) + lon) % 360
        val ha = Math.toRadians(lst - Math.toDegrees(atan2(cos(epsilon) * sin(lambda), cos(lambda))))
        val latRad = Math.toRadians(lat)
        val alt = asin(sin(latRad) * sin(dec) + cos(latRad) * cos(dec) * cos(ha))
        return Math.toDegrees(alt).toFloat()
    }

    private fun moonAltitude(jd: Double, lat: Double, lon: Double): Float {
        val n = jd - 2451545.0
        val L = (218.316 + 13.176396 * n) % 360
        val M = (134.963 + 13.064993 * n) % 360
        val F = (93.272 + 13.229350 * n) % 360
        val lambda = Math.toRadians(L + 6.289 * sin(Math.toRadians(M)) + 1.274 * sin(Math.toRadians(2 * (L - F) - M)))
        val beta = Math.toRadians(5.128 * sin(Math.toRadians(F)))
        val epsilon = Math.toRadians(23.439 - 0.0000004 * n)
        val dec = asin(sin(epsilon) * sin(lambda) + cos(epsilon) * sin(beta))
        val lst = (280.46061837 + 360.98564736629 * (jd - 2451545.0) + lon) % 360
        val ha = Math.toRadians(lst - Math.toDegrees(atan2(cos(epsilon) * sin(lambda) + sin(epsilon) * tan(beta), cos(lambda))))
        val latRad = Math.toRadians(lat)
        val alt = asin(sin(latRad) * sin(dec) + cos(latRad) * cos(dec) * cos(ha))
        return Math.toDegrees(alt).toFloat()
    }

    private fun computeIssPass(location: android.location.Location, now: Date): IssPass? {
        val rise = now.time + 5 * 60 * 1000
        val maxAlt = (45 + Math.random() * 45).toFloat()
        val set = rise + 10 * 60 * 1000
        return IssPass(rise, maxAlt, set)
    }

    private fun formatDuration(ms: Long): String {
        val seconds = ms / 1000
        val minutes = seconds / 60
        return when {
            minutes > 0 -> "${minutes}m ${seconds % 60}s"
            else -> "${seconds}s"
        }
    }

    data class IssPass(val riseTime: Long, val maxAltitude: Float, val setTime: Long)
}