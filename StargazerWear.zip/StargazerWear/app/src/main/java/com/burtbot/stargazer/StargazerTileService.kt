package com.burtbot.stargazer

import android.content.Context
import android.graphics.Color
import androidx.wear.protolayout.LayoutElementBuilders
import androidx.wear.protolayout.ModifiersBuilders
import androidx.wear.protolayout.TimelineBuilders
import androidx.wear.protolayout.TimelineBuilders.Timeline
import androidx.wear.protolayout.expression.DynamicBuilders
import androidx.wear.protolayout.expression.DynamicDataBuilders
import androidx.wear.protolayout.expression.DynamicTypeBuilders
import androidx.wear.protolayout.material.LayoutsBuilders
import androidx.wear.protolayout.material.TextBuilders
import androidx.wear.protolayout.protobuf.ByteString
import androidx.wear.tiles.TileService
import androidx.wear.tiles.builders.TileBuilders
import androidx.wear.tiles.builders.TileBuilders.Tile
import androidx.wear.tiles.renderer.TileRenderer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors

class StargazerTileService : TileService() {

    override fun onTileRequest(requestParams: TileBuilders.TileRequest): ListenableFuture<Tile> {
        return Executors.newSingleThreadExecutor().submit { createTile() }
    }

    override fun onTileResourcesRequest(requestParams: TileBuilders.ResourcesRequest): ListenableFuture<TileBuilders.Resources> {
        return Executors.newSingleThreadExecutor().submit { createResources() }
    }

    private fun createTile(): Tile {
        val now = Date()
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault()).apply { timeZone = TimeZone.getDefault() }
        val dateFormat = SimpleDateFormat("EEE, MMM d", Locale.getDefault()).apply { timeZone = TimeZone.getDefault() }
        
        val location = getLastKnownLocation()
        val (sunAlt, moonAlt) = if (location != null) {
            val jd = julianDate(now)
            sunAltitude(jd, location.latitude, location.longitude) to moonAltitude(jd, location.latitude, location.longitude)
        } else {
            0.0 to 0.0
        }

        val issPass = location?.let { computeIssPass(it, now) }
        val issText = issPass?.let { "ISS in ${formatDuration(it.riseTime - System.currentTimeMillis())}" } ?: "ISS: --"

        val layout = LayoutsBuilders.EdgeContentLayout.Builder()
            .setPrimaryContent(
                LayoutElementBuilders.Column.Builder()
                    .addContent(
                        TextBuilders.Text.Builder(
                            "Stargazer",
                            TextBuilders.FontStyles.Builder()
                                .setFontSize(28f)
                                .setColor(DynamicDataBuilders.DynamicColor.Fixed(DynamicBuilders.DynamicColorUtil.fromColorInt(Color.CYAN)))
                                .build()
                        ).build()
                    )
                    .addContent(
                        TextBuilders.Text.Builder(
                            "${timeFormat.format(now)}  •  ${dateFormat.format(now)}",
                            TextBuilders.FontStyles.Builder()
                                .setFontSize(14f)
                                .setColor(DynamicDataBuilders.DynamicColor.Fixed(DynamicBuilders.DynamicColorUtil.fromColorInt(Color.GRAY)))
                                .build()
                        ).build()
                    )
                    .addContent(
                        LayoutElementBuilders.Spacer.Builder().setHeight(8.dpToPx(resources)).build()
                    )
                    .addContent(
                        LayoutElementBuilders.Row.Builder()
                            .setHorizontalAlignment(LayoutElementBuilders.HorizontalAlignment.CENTER)
                            .addContent(
                                createCelestialChip("☀️ Sun", "${sunAlt.toInt()}°", Color.YELLOW)
                            )
                            .addContent(
                                LayoutElementBuilders.Spacer.Builder().setWidth(8.dpToPx(resources)).build()
                            )
                            .addContent(
                                createCelestialChip("🌙 Moon", "${moonAlt.toInt()}°", Color.rgb(245, 245, 220))
                            )
                            .build()
                    )
                    .addContent(
                        LayoutElementBuilders.Spacer.Builder().setHeight(8.dpToPx(resources)).build()
                    )
                    .addContent(
                        createCelestialChip("🛰️ ISS", issText, Color.CYAN)
                    )
                    .build()
            )
            .build()

        return Tile.Builder()
            .setTimeline(Timeline.Builder()
                .addTimelineEntry(TimelineBuilders.TimelineEntry.Builder()
                    .setLayout(layout)
                    .build())
                .build())
            .setRefreshIntervalMillis(60_000) // Update every minute
            .build()
    }

    private fun createCelestialChip(label: String, value: String, color: Int): LayoutElementBuilders.Box.Builder {
        return LayoutElementBuilders.Box.Builder()
            .setWidth(LayoutElementBuilders.DimensionBuilders.Weight(1f))
            .setBackground(
                ModifiersBuilders.Background.Builder()
                    .setColor(DynamicDataBuilders.DynamicColor.Fixed(DynamicBuilders.DynamicColorUtil.fromColorInt(Color.DKGRAY)))
                    .build()
            )
            .setContent(
                LayoutElementBuilders.Column.Builder()
                    .setVerticalAlignment(LayoutElementBuilders.VerticalAlignment.CENTER)
                    .addContent(
                        TextBuilders.Text.Builder(
                            label,
                            TextBuilders.FontStyles.Builder()
                                .setFontSize(12f)
                                .setColor(DynamicDataBuilders.DynamicColor.Fixed(DynamicBuilders.DynamicColorUtil.fromColorInt(Color.WHITE)))
                                .build()
                        ).build()
                    )
                    .addContent(
                        TextBuilders.Text.Builder(
                            value,
                            TextBuilders.FontStyles.Builder()
                                .setFontSize(16f)
                                .setColor(DynamicDataBuilders.DynamicColor.Fixed(DynamicBuilders.DynamicColorUtil.fromColorInt(color)))
                                .build()
                        ).build()
                    )
                    .build()
            )
            .build()
    }

    private fun createResources(): TileBuilders.Resources {
        return TileBuilders.Resources.Builder()
            .setVersion("1")
            .build()
    }

    private fun getLastKnownLocation(): android.location.Location? = null

    private fun julianDate(date: Date): Double = date.time / 1000.0 / 86400.0 + 2440587.5

    private fun sunAltitude(jd: Double, lat: Double, lon: Double): Float {
        val n = jd - 2451545.0
        val L = (280.460 + 0.9856474 * n) % 360
        val g = Math.toRadians((357.528 + 0.9856003 * n) % 360)
        val lambda = Math.toRadians(L + 1.915 * sin(g) + 0.020 * sin(2 * g))
        val epsilon = Math.toRadians(23.439 - 0.0000004 * n)
        val dec = asin(sin(epsilon) * sin(lambda))
        val lst = (280.46061837 + 360.98564736629 * (jd - 2451545.0) + lon) % 360
        val ha = Math.toRadians(lst - Math.toDegrees(atan2(cos(epsilon) * sin(lambda), cos(lambda))))
        val latRad = Math.toRadians(lat)
        val alt = asin(sin(latRad) * sin(dec) + cos(latRad) * cos(dec) * cos(ha))
        return Math.toDegrees(alt).toFloat()
    }

    private fun moonAltitude(jd: Double, lat: Double, lon: Double): Float {
        val n = jd - 2451545.0
        val L = (218.316 + 13.176396 * n) % 360
        val M = (134.963 + 13.064993 * n) % 360
        val F = (93.272 + 13.229350 * n) % 360
        val lambda = Math.toRadians(L + 6.289 * sin(Math.toRadians(M)) + 1.274 * sin(Math.toRadians(2 * (L - F) - M)))
        val beta = Math.toRadians(5.128 * sin(Math.toRadians(F)))
        val epsilon = Math.toRadians(23.439 - 0.0000004 * n)
        val dec = asin(sin(epsilon) * sin(lambda) + cos(epsilon) * sin(beta))
        val lst = (280.46061837 + 360.98564736629 * (jd - 2451545.0) + lon) % 360
        val ha = Math.toRadians(lst - Math.toDegrees(atan2(cos(epsilon) * sin(lambda) + sin(epsilon) * tan(beta), cos(lambda))))
        val latRad = Math.toRadians(lat)
        val alt = asin(sin(latRad) * sin(dec) + cos(latRad) * cos(dec) * cos(ha))
        return Math.toDegrees(alt).toFloat()
    }

    private fun computeIssPass(location: android.location.Location, now: Date): IssPass? {
        val rise = now.time + 5 * 60 * 1000
        val maxAlt = (45 + Math.random() * 45).toFloat()
        val set = rise + 10 * 60 * 1000
        return IssPass(rise, maxAlt, set)
    }

    private fun formatDuration(ms: Long): String {
        val seconds = ms / 1000
        val minutes = seconds / 60
        return when {
            minutes > 0 -> "${minutes}m ${seconds % 60}s"
            else -> "${seconds}s"
        }
    }

    data class IssPass(val riseTime: Long, val maxAltitude: Float, val setTime: Long)

    private val resources: android.content.res.Resources
        get() = applicationContext.resources

    private fun Int.dpToPx(resources: android.content.res.Resources): Int = (this * resources.displayMetrics.density).toInt()
}