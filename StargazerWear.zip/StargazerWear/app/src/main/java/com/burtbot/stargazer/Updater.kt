package com.burtbot.stargazer

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.provider.Settings
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** What the newest GitHub release offers. */
data class UpdateInfo(val version: Int, val tag: String, val apkUrl: String)

/** Checks the GitHub releases of this app, downloads the APK and hands it to the system installer. */
object Updater {
    private const val LATEST_URL = "https://api.github.com/repos/poslogic/StargazerWear/releases/latest"

    fun currentVersion(ctx: Context): Int =
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).longVersionCode.toInt()

    /** Returns the newest release, or null when it cannot be read. Run off the main thread. */
    fun fetchLatest(): UpdateInfo? {
        return try {
            val c = URL(LATEST_URL).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.setRequestProperty("User-Agent", "StargazerWear")
            if (c.responseCode != 200) {
                c.disconnect()
                return null
            }
            val body = c.inputStream.bufferedReader().use { it.readText() }
            c.disconnect()
            val json = JSONObject(body)
            val tag = json.getString("tag_name")
            val version = tag.substringAfterLast('.').filter { it.isDigit() }.toIntOrNull() ?: return null
            val assets = json.getJSONArray("assets")
            var url: String? = null
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.getString("name").endsWith(".apk")) {
                    url = a.getString("browser_download_url")
                    break
                }
            }
            if (url == null) null else UpdateInfo(version, tag, url)
        } catch (e: Exception) {
            null
        }
    }

    /** Downloads the APK into the app cache. Run off the main thread. */
    fun download(ctx: Context, url: String): File? {
        return try {
            val dir = File(ctx.cacheDir, "updates")
            dir.mkdirs()
            val out = File(dir, "update.apk")
            var current = url
            var redirects = 0
            while (true) {
                val c = URL(current).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 60000
                c.instanceFollowRedirects = false
                c.setRequestProperty("User-Agent", "StargazerWear")
                val code = c.responseCode
                if (code in 300..399 && redirects < 6) {
                    current = c.getHeaderField("Location") ?: return null
                    c.disconnect()
                    redirects++
                    continue
                }
                if (code != 200) {
                    c.disconnect()
                    return null
                }
                c.inputStream.use { input -> out.outputStream().use { input.copyTo(it) } }
                c.disconnect()
                break
            }
            if (out.length() > 0) out else null
        } catch (e: Exception) {
            null
        }
    }

    fun canInstall(ctx: Context): Boolean = ctx.packageManager.canRequestPackageInstalls()

    /** Opens the "install unknown apps" setting for this app. */
    fun openInstallPermissionSettings(ctx: Context): Boolean {
        return try {
            val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            true
        } catch (e: Exception) {
            // some watches have no such settings screen
            false
        }
    }

    /** Streams the APK into a PackageInstaller session. The system then asks the user to confirm. */
    fun install(ctx: Context, apk: File): Boolean {
        return try {
            val installer = ctx.packageManager.packageInstaller
            val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
            val id = installer.createSession(params)
            installer.openSession(id).use { session ->
                apk.inputStream().use { input ->
                    session.openWrite("stargazer.apk", 0, apk.length()).use { out ->
                        input.copyTo(out)
                        session.fsync(out)
                    }
                }
                val intent = Intent(ctx, InstallResultReceiver::class.java)
                val pending = PendingIntent.getBroadcast(
                    ctx, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                )
                session.commit(pending.intentSender)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}

/** Receives the installer result and shows the system confirmation screen when needed. */
class InstallResultReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            @Suppress("DEPRECATION")
            val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
            if (confirm != null) {
                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(confirm)
            }
        } else if (status != PackageInstaller.STATUS_SUCCESS) {
            val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "Install failed"
            Prefs.get(context).edit().putString("update_error", msg).apply()
        }
    }
}
