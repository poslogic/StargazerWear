package com.burtbot.stargazer

import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/** Low-precision sky maths: good enough for a naked-eye star map. */
object Astro {

    data class Body(
        val name: String,
        val az: Double,      // degrees, 0 = north, 90 = east
        val alt: Double,     // degrees above horizon
        val color: Long,     // 0xAARRGGBB
        val radius: Float,   // drawing radius in dp
        val labelled: Boolean,
        val kind: String     // sun, moon, planet, star, iss, starlink
    )

    data class DayEvents(val riseMs: Long?, val setMs: Long?, val peakMs: Long, val peakAlt: Double)

    private data class Star(
        val name: String,
        val ra: Double,
        val dec: Double,
        val mag: Double,
        val constellation: String,
        val distLy: Int
    )

    data class StarInfo(val constellation: String, val distLy: Int, val mag: Double)

    private val stars = listOf(
        Star("Sirius", 101.29, -16.72, -1.46, "Canis Major", 9),
        Star("Canopus", 95.99, -52.70, -0.74, "Carina", 310),
        Star("Arcturus", 213.92, 19.18, -0.05, "Bootes", 37),
        Star("Vega", 279.23, 38.78, 0.03, "Lyra", 25),
        Star("Capella", 79.17, 45.99, 0.08, "Auriga", 43),
        Star("Rigel", 78.63, -8.20, 0.13, "Orion", 860),
        Star("Procyon", 114.83, 5.22, 0.34, "Canis Minor", 11),
        Star("Betelgeuse", 88.79, 7.41, 0.50, "Orion", 550),
        Star("Altair", 297.70, 8.87, 0.76, "Aquila", 17),
        Star("Aldebaran", 68.98, 16.51, 0.86, "Taurus", 65),
        Star("Antares", 247.35, -26.43, 1.06, "Scorpius", 550),
        Star("Spica", 201.30, -11.16, 0.97, "Virgo", 250),
        Star("Deneb", 310.36, 45.28, 1.25, "Cygnus", 2600),
        Star("Regulus", 152.09, 11.97, 1.35, "Leo", 79),
        Star("Fomalhaut", 344.41, -29.62, 1.16, "Piscis Austrinus", 25),
        Star("Polaris", 37.95, 89.26, 1.98, "Ursa Minor", 430)
    )

    const val STAR_COLOR = 0xFFFFFFFFL

    fun starInfo(name: String): StarInfo? {
        val s = stars.firstOrNull { it.name == name } ?: return null
        return StarInfo(s.constellation, s.distLy, s.mag)
    }

    val planetNames = listOf("Mercury", "Venus", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune")

    /** Pages shown when swiping sideways. */
    val pageBodies = listOf("Sun", "Moon") + planetNames

    const val SUN_COLOR = 0xFFFFD83AL
    const val MOON_COLOR = 0xFF9DB4CCL

    private val planetLook = mapOf(
        "Mercury" to Pair(0xFFC9C2BAL, 5f),
        "Venus" to Pair(0xFFFFF0B0L, 8f),
        "Mars" to Pair(0xFFFF6A3DL, 6f),
        "Jupiter" to Pair(0xFFF0D2A0L, 8f),
        "Saturn" to Pair(0xFFE8CF8AL, 7f),
        "Uranus" to Pair(0xFF9FE8EEL, 5f),
        "Neptune" to Pair(0xFF6F8CFFL, 5f)
    )

    // JPL "Approximate Positions of the Planets" (1800-2050), J2000 ecliptic.
    // a, a', e, e', I, I', L, L', long.peri, long.peri', long.node, long.node'
    private val planetElements = mapOf(
        "Mercury" to doubleArrayOf(0.38709927, 0.00000037, 0.20563593, 0.00001906, 7.00497902, -0.00594749, 252.25032350, 149472.67411175, 77.45779628, 0.16047689, 48.33076593, -0.12534081),
        "Venus" to doubleArrayOf(0.72333566, 0.00000390, 0.00677672, -0.00004107, 3.39467605, -0.00078890, 181.97909950, 58517.81538729, 131.60246718, 0.00268329, 76.67984255, -0.27769418),
        "Mars" to doubleArrayOf(1.52371034, 0.00001847, 0.09339410, 0.00007882, 1.84969142, -0.00813131, -4.55343205, 19140.30268499, -23.94362959, 0.44441088, 49.55953891, -0.29257343),
        "Jupiter" to doubleArrayOf(5.20288700, -0.00011607, 0.04838624, -0.00013253, 1.30439695, -0.00183714, 34.39644051, 3034.74612775, 14.72847983, 0.21252668, 100.47390909, 0.20469106),
        "Saturn" to doubleArrayOf(9.53667594, -0.00125060, 0.05386179, -0.00050991, 2.48599187, 0.00193609, 49.95424423, 1222.49362201, 92.59887831, -0.41897216, 113.66242448, -0.28867794),
        "Uranus" to doubleArrayOf(19.18916464, -0.00196176, 0.04725744, -0.00004397, 0.77263783, -0.00242939, 313.23810451, 428.48202785, 170.95427630, 0.40805281, 74.01692503, 0.04240589),
        "Neptune" to doubleArrayOf(30.06992276, 0.00026291, 0.00859048, 0.00005105, 1.77004347, 0.00035372, -55.12002969, 218.45945325, 44.96476227, -0.32241464, 131.78422574, -0.00508664)
    )

    private val earthElements = doubleArrayOf(1.00000261, 0.00000562, 0.01671123, -0.00004392, -0.00001531, -0.01294668, 100.46457166, 35999.37244981, 102.93768193, 0.32327364, 0.0, 0.0)

    private fun rad(d: Double) = Math.toRadians(d)
    private fun deg(r: Double) = Math.toDegrees(r)

    private fun norm360(d: Double): Double {
        val m = d % 360.0
        return if (m < 0) m + 360.0 else m
    }

    private fun norm180(d: Double): Double {
        val m = norm360(d)
        return if (m > 180.0) m - 360.0 else m
    }

    fun julianDate(epochMs: Long): Double = epochMs / 86400000.0 + 2440587.5

    /** Returns (azimuth, altitude) in degrees. */
    private fun toHorizontal(raDeg: Double, decDeg: Double, latDeg: Double, lonDeg: Double, jd: Double): Pair<Double, Double> {
        val lst = norm360(280.46061837 + 360.98564736629 * (jd - 2451545.0) + lonDeg)
        val ha = rad(lst - raDeg)
        val lat = rad(latDeg)
        val dec = rad(decDeg)
        val sinAlt = sin(lat) * sin(dec) + cos(lat) * cos(dec) * cos(ha)
        val alt = asin(sinAlt.coerceIn(-1.0, 1.0))
        val az = atan2(-sin(ha) * cos(dec), cos(lat) * sin(dec) - sin(lat) * cos(dec) * cos(ha))
        return Pair(norm360(deg(az)), deg(alt))
    }

    /** Rough precession from J2000 to the date, so stars and planets match the Sun and Moon. */
    private fun precess(raDeg: Double, decDeg: Double, jd: Double): Pair<Double, Double> {
        val years = (jd - 2451545.0) / 365.25
        val ra = rad(raDeg)
        val dec = rad(decDeg)
        val dRa = (3.075 + 1.336 * sin(ra) * tan(dec)) * years * 15.0 / 3600.0
        val dDec = 20.04 * cos(ra) * years / 3600.0
        return Pair(norm360(raDeg + dRa), decDeg + dDec)
    }

    /** Returns (RA, Dec) in degrees, of date. */
    fun sunEquatorial(jd: Double): Pair<Double, Double> {
        val n = jd - 2451545.0
        val l = 280.460 + 0.9856474 * n
        val g = rad(357.528 + 0.9856003 * n)
        val lambda = rad(l + 1.915 * sin(g) + 0.020 * sin(2 * g))
        val eps = rad(23.439 - 0.0000004 * n)
        val ra = atan2(cos(eps) * sin(lambda), cos(lambda))
        val dec = asin(sin(eps) * sin(lambda))
        return Pair(norm360(deg(ra)), deg(dec))
    }

    private fun moonEquatorial(jd: Double): Pair<Double, Double> {
        val n = jd - 2451545.0
        val l = 218.316 + 13.176396 * n
        val m = 134.963 + 13.064993 * n
        val f = 93.272 + 13.229350 * n
        val lon = rad(l + 6.289 * sin(rad(m)))
        val lat = rad(5.128 * sin(rad(f)))
        val eps = rad(23.439 - 0.0000004 * n)
        val ra = atan2(sin(lon) * cos(eps) - tan(lat) * sin(eps), cos(lon))
        val dec = asin(sin(lat) * cos(eps) + cos(lat) * sin(eps) * sin(lon))
        return Pair(norm360(deg(ra)), deg(dec))
    }

    /** Heliocentric ecliptic coordinates (AU) from orbital elements. */
    private fun helio(el: DoubleArray, t: Double): DoubleArray {
        val a = el[0] + el[1] * t
        val e = el[2] + el[3] * t
        val inc = rad(el[4] + el[5] * t)
        val l = el[6] + el[7] * t
        val peri = el[8] + el[9] * t
        val node = rad(el[10] + el[11] * t)
        val w = rad(peri) - node
        val m = rad(norm180(l - peri))
        var ea = m + e * sin(m)
        for (k in 0 until 8) {
            ea -= (ea - e * sin(ea) - m) / (1.0 - e * cos(ea))
        }
        val xp = a * (cos(ea) - e)
        val yp = a * sqrt(1.0 - e * e) * sin(ea)
        val cw = cos(w)
        val sw = sin(w)
        val cn = cos(node)
        val sn = sin(node)
        val ci = cos(inc)
        val si = sin(inc)
        val x = (cw * cn - sw * sn * ci) * xp + (-sw * cn - cw * sn * ci) * yp
        val y = (cw * sn + sw * cn * ci) * xp + (-sw * sn + cw * cn * ci) * yp
        val z = (sw * si) * xp + (cw * si) * yp
        return doubleArrayOf(x, y, z)
    }

    private fun planetEquatorial(name: String, jd: Double): Pair<Double, Double> {
        val el = planetElements[name] ?: return Pair(0.0, 0.0)
        val t = (jd - 2451545.0) / 36525.0
        val p = helio(el, t)
        val earth = helio(earthElements, t)
        val gx = p[0] - earth[0]
        val gy = p[1] - earth[1]
        val gz = p[2] - earth[2]
        val eps = rad(23.43928)
        val ye = gy * cos(eps) - gz * sin(eps)
        val ze = gy * sin(eps) + gz * cos(eps)
        val dist = sqrt(gx * gx + ye * ye + ze * ze)
        val ra = norm360(deg(atan2(ye, gx)))
        val dec = deg(asin((ze / dist).coerceIn(-1.0, 1.0)))
        return precess(ra, dec, jd)
    }

    private fun equatorial(name: String, jd: Double): Pair<Double, Double> = when (name) {
        "Sun" -> sunEquatorial(jd)
        "Moon" -> moonEquatorial(jd)
        else -> {
            val star = stars.firstOrNull { it.name == name }
            if (star != null) precess(star.ra, star.dec, jd) else planetEquatorial(name, jd)
        }
    }

    /** Returns (azimuth, altitude) in degrees for the Sun, Moon or a planet. */
    fun horizontalOf(name: String, epochMs: Long, latDeg: Double, lonDeg: Double): Pair<Double, Double> {
        val jd = julianDate(epochMs)
        val eq = equatorial(name, jd)
        return toHorizontal(eq.first, eq.second, latDeg, lonDeg, jd)
    }

    fun sunAltitude(epochMs: Long, latDeg: Double, lonDeg: Double): Double =
        horizontalOf("Sun", epochMs, latDeg, lonDeg).second

    /** Distance from Earth in astronomical units. */
    fun planetDistanceAu(name: String, epochMs: Long): Double {
        val el = planetElements[name] ?: return 0.0
        val t = (julianDate(epochMs) - 2451545.0) / 36525.0
        val p = helio(el, t)
        val earth = helio(earthElements, t)
        val dx = p[0] - earth[0]
        val dy = p[1] - earth[1]
        val dz = p[2] - earth[2]
        return sqrt(dx * dx + dy * dy + dz * dz)
    }

    /** Fraction of the Moon's disc that is lit, 0 to 1. */
    fun moonIllumination(epochMs: Long): Double {
        val jd = julianDate(epochMs)
        val sun = sunEquatorial(jd)
        val moon = moonEquatorial(jd)
        val d1 = rad(sun.second)
        val d2 = rad(moon.second)
        val dra = rad(sun.first - moon.first)
        val cosElong = sin(d1) * sin(d2) + cos(d1) * cos(d2) * cos(dra)
        return ((1.0 - cosElong) / 2.0).coerceIn(0.0, 1.0)
    }

    /** Rise, set and highest point within the 24 hours after dayStartMs. */
    fun dayEvents(name: String, latDeg: Double, lonDeg: Double, dayStartMs: Long): DayEvents {
        val step = 5L * 60L * 1000L
        val h0 = if (name == "Sun" || name == "Moon") -0.83 else -0.57
        var prevAlt = horizontalOf(name, dayStartMs, latDeg, lonDeg).second
        var rise: Long? = null
        var set: Long? = null
        var peakAlt = prevAlt
        var peakMs = dayStartMs
        for (i in 1..288) {
            val t = dayStartMs + i * step
            val alt = horizontalOf(name, t, latDeg, lonDeg).second
            if (prevAlt < h0 && alt >= h0 && rise == null) {
                rise = t - step + ((h0 - prevAlt) / (alt - prevAlt) * step).toLong()
            }
            if (prevAlt >= h0 && alt < h0 && set == null) {
                set = t - step + ((prevAlt - h0) / (prevAlt - alt) * step).toLong()
            }
            if (alt > peakAlt) {
                peakAlt = alt
                peakMs = t
            }
            prevAlt = alt
        }
        return DayEvents(rise, set, peakMs, peakAlt)
    }

    /** Everything currently above the horizon for the given place and time. */
    fun visibleBodies(epochMs: Long, latDeg: Double, lonDeg: Double): List<Body> {
        val jd = julianDate(epochMs)
        val result = mutableListOf<Body>()

        val sun = sunEquatorial(jd)
        val sunHor = toHorizontal(sun.first, sun.second, latDeg, lonDeg, jd)
        result.add(Body("Sun", sunHor.first, sunHor.second, SUN_COLOR, 13f, true, "sun"))

        val moon = moonEquatorial(jd)
        val moonHor = toHorizontal(moon.first, moon.second, latDeg, lonDeg, jd)
        result.add(Body("Moon", moonHor.first, moonHor.second, MOON_COLOR, 11f, true, "moon"))

        for (name in planetNames) {
            val eq = planetEquatorial(name, jd)
            val hor = toHorizontal(eq.first, eq.second, latDeg, lonDeg, jd)
            val look = planetLook[name]
            val color = look?.first ?: 0xFFFFFFFFL
            val radius = look?.second ?: 5f
            result.add(Body(name, hor.first, hor.second, color, radius, true, "planet"))
        }

        for (s in stars) {
            val p = precess(s.ra, s.dec, jd)
            val hor = toHorizontal(p.first, p.second, latDeg, lonDeg, jd)
            val r = (4.5 - s.mag * 1.3).toFloat().coerceIn(2.5f, 8f)
            result.add(Body(s.name, hor.first, hor.second, STAR_COLOR, r, s.mag < 1.4, "star"))
        }

        return result.filter { it.alt > 0.0 }
    }
}
