package com.burtbot.stargazer

import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.tan

/** Low-precision sky maths: good enough for a naked-eye star map. */
object Astro {

    data class Body(
        val name: String,
        val az: Double,      // degrees, 0 = north, 90 = east
        val alt: Double,     // degrees above horizon
        val color: Long,     // 0xAARRGGBB
        val radius: Float,   // drawing radius in px
        val labelled: Boolean
    )

    private data class Star(val name: String, val ra: Double, val dec: Double, val mag: Double)

    private val stars = listOf(
        Star("Sirius", 101.29, -16.72, -1.46),
        Star("Canopus", 95.99, -52.70, -0.74),
        Star("Arcturus", 213.92, 19.18, -0.05),
        Star("Vega", 279.23, 38.78, 0.03),
        Star("Capella", 79.17, 45.99, 0.08),
        Star("Rigel", 78.63, -8.20, 0.13),
        Star("Procyon", 114.83, 5.22, 0.34),
        Star("Betelgeuse", 88.79, 7.41, 0.50),
        Star("Altair", 297.70, 8.87, 0.76),
        Star("Aldebaran", 68.98, 16.51, 0.86),
        Star("Antares", 247.35, -26.43, 1.06),
        Star("Spica", 201.30, -11.16, 0.97),
        Star("Deneb", 310.36, 45.28, 1.25),
        Star("Regulus", 152.09, 11.97, 1.35),
        Star("Fomalhaut", 344.41, -29.62, 1.16),
        Star("Polaris", 37.95, 89.26, 1.98)
    )

    private fun rad(d: Double) = Math.toRadians(d)
    private fun deg(r: Double) = Math.toDegrees(r)

    private fun norm360(d: Double): Double {
        val m = d % 360.0
        return if (m < 0) m + 360.0 else m
    }

    fun julianDate(epochMs: Long): Double = epochMs / 86400000.0 + 2440587.5

    /** Returns (azimuth, altitude) in degrees. */
    private fun toHorizontal(raDeg: Double, decDeg: Double, latDeg: Double, lonDeg: Double, jd: Double): Pair<Double, Double> {
        val lst = norm360(280.46061837 + 360.98564736629 * (jd - 2451545.0) + lonDeg)
        val ha = rad(lst - raDeg)
        val lat = rad(latDeg)
        val dec = rad(decDeg)
        val sinAlt = sin(lat) * sin(dec) + cos(lat) * cos(dec) * cos(ha)
        val alt = asin(sinAlt.coerceIn(-1.0, 1.0))
        val az = atan2(-sin(ha) * cos(dec), cos(lat) * sin(dec) - sin(lat) * cos(dec) * cos(ha))
        return Pair(norm360(deg(az)), deg(alt))
    }

    /** Returns (RA, Dec) in degrees. */
    private fun sunEquatorial(jd: Double): Pair<Double, Double> {
        val n = jd - 2451545.0
        val l = 280.460 + 0.9856474 * n
        val g = rad(357.528 + 0.9856003 * n)
        val lambda = rad(l + 1.915 * sin(g) + 0.020 * sin(2 * g))
        val eps = rad(23.439 - 0.0000004 * n)
        val ra = atan2(cos(eps) * sin(lambda), cos(lambda))
        val dec = asin(sin(eps) * sin(lambda))
        return Pair(norm360(deg(ra)), deg(dec))
    }

    private fun moonEquatorial(jd: Double): Pair<Double, Double> {
        val n = jd - 2451545.0
        val l = 218.316 + 13.176396 * n
        val m = 134.963 + 13.064993 * n
        val f = 93.272 + 13.229350 * n
        val lon = rad(l + 6.289 * sin(rad(m)))
        val lat = rad(5.128 * sin(rad(f)))
        val eps = rad(23.439 - 0.0000004 * n)
        val ra = atan2(sin(lon) * cos(eps) - tan(lat) * sin(eps), cos(lon))
        val dec = asin(sin(lat) * cos(eps) + cos(lat) * sin(eps) * sin(lon))
        return Pair(norm360(deg(ra)), deg(dec))
    }

    /** Everything currently above the horizon for the given place and time. */
    fun visibleBodies(epochMs: Long, latDeg: Double, lonDeg: Double): List<Body> {
        val jd = julianDate(epochMs)
        val result = mutableListOf<Body>()

        val sun = sunEquatorial(jd)
        val sunHor = toHorizontal(sun.first, sun.second, latDeg, lonDeg, jd)
        result.add(Body("Sun", sunHor.first, sunHor.second, 0xFFFFD700, 12f, true))

        val moon = moonEquatorial(jd)
        val moonHor = toHorizontal(moon.first, moon.second, latDeg, lonDeg, jd)
        result.add(Body("Moon", moonHor.first, moonHor.second, 0xFFF5F5DC, 10f, true))

        for (s in stars) {
            val hor = toHorizontal(s.ra, s.dec, latDeg, lonDeg, jd)
            val r = (4.5 - s.mag * 1.3).toFloat().coerceIn(2.5f, 8f)
            result.add(Body(s.name, hor.first, hor.second, 0xFFFFFFFF, r, s.mag < 0.6))
        }

        return result.filter { it.alt > 0.0 }
    }
}
