package com.burtbot.stargazer

import androidx.compose.foundation.Canvas
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.runtime.Composable

private data class Look(val light: Color, val base: Color, val dark: Color)

private fun lookFor(name: String): Look = when (name) {
    "Sun" -> Look(Color(0xFFFFF3A0), Color(0xFFFFD83A), Color(0xFFFF9D1C))
    "Moon" -> Look(Color(0xFFD5E2F0), Color(0xFF9DB4CC), Color(0xFF5E7390))
    "Mercury" -> Look(Color(0xFFE2DCD4), Color(0xFFB0A89E), Color(0xFF5E5852))
    "Venus" -> Look(Color(0xFFFFF8D0), Color(0xFFF0D58A), Color(0xFFB98B3E))
    "Mars" -> Look(Color(0xFFFF9A6B), Color(0xFFD9542B), Color(0xFF7A2A12))
    "Jupiter" -> Look(Color(0xFFF8E6C4), Color(0xFFD9B286), Color(0xFF8A5A33))
    "Saturn" -> Look(Color(0xFFF6E6B4), Color(0xFFD9BE7E), Color(0xFF8C7440))
    "Uranus" -> Look(Color(0xFFD2FAFC), Color(0xFF8FDDE6), Color(0xFF3F8E9C))
    else -> Look(Color(0xFF9DB4FF), Color(0xFF3F5FE0), Color(0xFF1A2A80)) // Neptune
}

/** Stylised planet pictures drawn with the Canvas, so no image files are needed. */
@Composable
fun PlanetArt(name: String, modifier: Modifier = Modifier) {
    val look = lookFor(name)
    Canvas(modifier = modifier) {
        val c = Offset(size.width / 2f, size.height / 2f)
        val r = minOf(size.width, size.height) / 2f * (if (name == "Saturn") 0.58f else 0.82f)

        if (name == "Sun") {
            drawCircle(color = look.base.copy(alpha = 0.25f), radius = r * 1.25f, center = c)
        }

        val ringW = r * 3.0f
        val ringH = r * 0.9f
        val ringTop = Offset(c.x - ringW / 2f, c.y - ringH / 2f)
        val ringSize = Size(ringW, ringH)
        val ringColor = Color(0xFFE9D8A6)

        if (name == "Saturn") {
            drawArc(
                color = ringColor.copy(alpha = 0.7f), startAngle = 180f, sweepAngle = 180f, useCenter = false,
                topLeft = ringTop, size = ringSize, style = Stroke(width = r * 0.22f)
            )
        }

        val brush = Brush.radialGradient(
            colors = listOf(look.light, look.base, look.dark),
            center = Offset(c.x - r * 0.35f, c.y - r * 0.35f),
            radius = r * 1.7f
        )
        drawCircle(brush = brush, radius = r, center = c)

        val discPath = Path()
        discPath.addOval(Rect(c.x - r, c.y - r, c.x + r, c.y + r))

        if (name == "Jupiter" || name == "Saturn") {
            clipPath(discPath) {
                val bandColor = look.dark.copy(alpha = 0.35f)
                var i = 0
                while (i < 5) {
                    val y = c.y - r + r * 2f * (0.18f + 0.16f * i)
                    drawRect(color = bandColor, topLeft = Offset(c.x - r, y), size = Size(r * 2f, r * 0.09f))
                    i += 1
                }
            }
        }
        if (name == "Jupiter") {
            drawCircle(color = Color(0xFFB5502C).copy(alpha = 0.8f), radius = r * 0.09f, center = Offset(c.x + r * 0.3f, c.y + r * 0.25f))
        }
        if (name == "Moon" || name == "Mercury") {
            clipPath(discPath) {
                val crater = look.dark.copy(alpha = 0.45f)
                drawCircle(color = crater, radius = r * 0.16f, center = Offset(c.x - r * 0.3f, c.y - r * 0.1f))
                drawCircle(color = crater, radius = r * 0.10f, center = Offset(c.x + r * 0.25f, c.y - r * 0.4f))
                drawCircle(color = crater, radius = r * 0.12f, center = Offset(c.x + r * 0.3f, c.y + r * 0.3f))
                drawCircle(color = crater, radius = r * 0.07f, center = Offset(c.x - r * 0.1f, c.y + r * 0.5f))
            }
        }
        if (name == "Mars") {
            drawCircle(color = Color.White.copy(alpha = 0.85f), radius = r * 0.16f, center = Offset(c.x, c.y - r * 0.86f))
        }

        if (name == "Saturn") {
            drawArc(
                color = ringColor.copy(alpha = 0.9f), startAngle = 0f, sweepAngle = 180f, useCenter = false,
                topLeft = ringTop, size = ringSize, style = Stroke(width = r * 0.22f)
            )
        }
    }
}
