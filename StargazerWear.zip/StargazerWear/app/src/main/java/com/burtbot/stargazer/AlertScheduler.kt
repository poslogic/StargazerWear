package com.burtbot.stargazer

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object AlertScheduler {
    const val ACTION_ALERT = "com.burtbot.stargazer.PASS_ALERT"
    private const val LEAD_MS = 5L * 60L * 1000L

    private fun pendingIntent(ctx: Context): PendingIntent {
        val intent = Intent(ctx, PassAlertReceiver::class.java).setAction(ACTION_ALERT)
        return PendingIntent.getBroadcast(
            ctx, 1001, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Sets (or cancels) the alarm for five minutes before the next visible ISS pass. */
    fun scheduleNext(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(ctx)
        am.cancel(pi)
        if (!Prefs.get(ctx).getBoolean("alert_on", false)) return

        val now = System.currentTimeMillis()
        val next = PassStore.load(ctx)
            .filter { it.name == "ISS" && it.startMs - LEAD_MS > now }
            .minByOrNull { it.startMs } ?: return
        val trigger = next.startMs - LEAD_MS
        Prefs.get(ctx).edit().putLong("alert_pass_start", next.startMs).apply()
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
        }
    }
}
