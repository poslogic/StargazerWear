package com.burtbot.stargazer

import androidx.concurrent.futures.ResolvableFuture
import androidx.wear.protolayout.ActionBuilders
import androidx.wear.protolayout.ColorBuilders.argb
import androidx.wear.protolayout.DimensionBuilders
import androidx.wear.protolayout.DimensionBuilders.sp
import androidx.wear.protolayout.LayoutElementBuilders
import androidx.wear.protolayout.ModifiersBuilders
import androidx.wear.protolayout.ResourceBuilders
import androidx.wear.protolayout.TimelineBuilders
import androidx.wear.tiles.RequestBuilders
import androidx.wear.tiles.TileBuilders
import androidx.wear.tiles.TileService
import com.google.common.util.concurrent.ListenableFuture

/** Tile showing the next visible ISS and Starlink passes. Tap it to open the app. */
class IssTileService : TileService() {

    override fun onTileRequest(requestParams: RequestBuilders.TileRequest): ListenableFuture<TileBuilders.Tile> {
        val now = System.currentTimeMillis()
        val passes = PassStore.load(this).filter { it.endMs > now }
        val iss = passes.filter { it.name == "ISS" }.minByOrNull { it.startMs }
        val starlink = passes.filter { it.name == "Starlink" }.minByOrNull { it.startMs }

        val column = LayoutElementBuilders.Column.Builder()
            .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER)
            .addContent(textLine("Stargazer", 0xFFFFFFFF.toInt(), 13f))
            .addContent(textLine(headline("ISS", iss, now), 0xFF2EE6FF.toInt(), 16f))
            .addContent(textLine(detail(iss), 0xFFB0B0B0.toInt(), 12f))
            .addContent(textLine(headline("Starlink", starlink, now), 0xFFFF6BFF.toInt(), 16f))
            .addContent(textLine(detail(starlink), 0xFFB0B0B0.toInt(), 12f))
            .build()

        val launch = ActionBuilders.LaunchAction.Builder()
            .setAndroidActivity(
                ActionBuilders.AndroidActivity.Builder()
                    .setPackageName(packageName)
                    .setClassName(MainActivity::class.java.name)
                    .build()
            )
            .build()
        val clickable = ModifiersBuilders.Clickable.Builder()
            .setId("open_app")
            .setOnClick(launch)
            .build()
        val modifiers = ModifiersBuilders.Modifiers.Builder()
            .setClickable(clickable)
            .build()

        val box = LayoutElementBuilders.Box.Builder()
            .setWidth(DimensionBuilders.expand())
            .setHeight(DimensionBuilders.expand())
            .setModifiers(modifiers)
            .addContent(column)
            .build()

        val tile = TileBuilders.Tile.Builder()
            .setResourcesVersion("1")
            .setTileTimeline(TimelineBuilders.Timeline.fromLayoutElement(box))
            .setFreshnessIntervalMillis(10L * 60L * 1000L)
            .build()

        val future = ResolvableFuture.create<TileBuilders.Tile>()
        future.set(tile)
        return future
    }

    override fun onTileResourcesRequest(requestParams: RequestBuilders.ResourcesRequest): ListenableFuture<ResourceBuilders.Resources> {
        val future = ResolvableFuture.create<ResourceBuilders.Resources>()
        future.set(ResourceBuilders.Resources.Builder().setVersion("1").build())
        return future
    }

    private fun textLine(text: String, color: Int, size: Float): LayoutElementBuilders.LayoutElement {
        return LayoutElementBuilders.Text.Builder()
            .setText(text)
            .setMaxLines(1)
            .setFontStyle(
                LayoutElementBuilders.FontStyle.Builder()
                    .setSize(sp(size))
                    .setColor(argb(color))
                    .build()
            )
            .build()
    }

    private fun headline(name: String, pass: Pass?, now: Long): String {
        if (pass == null) return "$name: open app"
        if (pass.startMs <= now) return "$name: now!"
        return name + " " + dayLabel(pass.startMs, now) + " " + clock(pass.startMs)
    }

    private fun detail(pass: Pass?): String {
        if (pass == null) return " "
        return "max " + pass.maxEl.toInt() + "\u00B0 " + compassName(pass.startAz) + " to " + compassName(pass.endAz)
    }
}
