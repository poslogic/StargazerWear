package com.burtbot.stargazer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.material.Text
import java.util.Locale

/** Full-screen information card shown when a star, planet or satellite is tapped. */
@Composable
fun InfoOverlay(
    body: Astro.Body,
    lat: Double,
    lon: Double,
    nowMs: Long,
    passes: List<Pass>,
    redMode: Boolean,
    onDismiss: () -> Unit
) {
    val isSkyBody = body.kind == "sun" || body.kind == "moon" || body.kind == "planet" || body.kind == "star"
    val dayStart = startOfDay(nowMs)
    val events = remember(body.name, dayStart, lat, lon) {
        if (isSkyBody) Astro.dayEvents(body.name, lat, lon, dayStart) else null
    }

    val titleColor = if (redMode) Color(0xFFFF6666) else Color(body.color)
    val textColor = if (redMode) Color(0xFFFF5555) else Color.White
    val lines = ArrayList<String>()

    when (body.kind) {
        "sun" -> lines.add("Our star. Never look at it directly.")
        "moon" -> lines.add("Lit: " + (Astro.moonIllumination(nowMs) * 100.0).toInt() + "%")
        "planet" -> lines.add(
            "Planet, " + String.format(Locale.US, "%.1f", Astro.planetDistanceAu(body.name, nowMs)) + " AU away"
        )
        "star" -> {
            val si = Astro.starInfo(body.name)
            if (si != null) {
                lines.add(si.constellation + ", " + si.distLy + " light years")
                lines.add("Brightness (mag): " + String.format(Locale.US, "%.1f", si.mag))
            }
        }
        "iss" -> lines.add("Space station, about 420 km up")
        "starlink" -> lines.add("Starlink satellite")
    }

    if (body.alt > 0.0) {
        lines.add("Now " + body.alt.toInt() + "\u00B0 up, " + compassName(body.az))
    }

    if (events != null) {
        if (events.peakAlt < -0.8) {
            lines.add("Does not rise today")
        } else {
            lines.add("Rise " + clock(events.riseMs) + "   Set " + clock(events.setMs))
            lines.add("Highest " + clock(events.peakMs) + "  " + events.peakAlt.toInt() + "\u00B0")
        }
    } else {
        val satName = if (body.kind == "iss") "ISS" else "Starlink"
        val next = passes.filter { it.name == satName && it.endMs > nowMs }.minByOrNull { it.startMs }
        if (next != null) {
            lines.add("Next pass " + dayLabel(next.startMs, nowMs) + " " + clock(next.startMs))
            lines.add(
                "max " + next.maxEl.toInt() + "\u00B0, " + compassName(next.startAz) + " to " + compassName(next.endAz)
            )
        } else {
            lines.add("No visible pass soon")
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xF2000000))
            .clickable { onDismiss() }
            .padding(horizontal = 26.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val hasArt = body.kind == "sun" || body.kind == "moon" || body.kind == "planet"
        if (hasArt && !redMode) {
            PlanetArt(name = body.name, modifier = Modifier.size(46.dp))
        }
        Text(
            text = body.name,
            color = titleColor,
            fontSize = 19.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        for (line in lines) {
            Text(
                text = line,
                color = textColor,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
        Text(
            text = "Tap to close",
            color = textColor.copy(alpha = 0.5f),
            fontSize = 10.sp,
            modifier = Modifier.padding(top = 6.dp)
        )
    }
}
