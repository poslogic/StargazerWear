package com.burtbot.stargazer

import android.Manifest
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CompassCalibration
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.drawscope.drawCircle
import androidx.compose.ui.graphics.drawscope.drawLine
import androidx.compose.ui.graphics.drawscope.drawRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.wear.compose.material.Chip
import androidx.wear.compose.material.Vignette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class MainActivity : ComponentActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var magnetometer: Sensor? = null
    private var gravity: FloatArray? = null
    private var geomagnetic: FloatArray? = null
    private var azimuth = 0f
    private val azimuthState = mutableStateOf(0f)

    private val locationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startLocationUpdates()
    }

    private var currentLocation: Location? = null
    private val locationState = mutableStateOf<Location?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StargazerTheme() }

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

        checkLocationPermission()
    }

    private fun checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            startLocationUpdates()
        } else {
            locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    private fun startLocationUpdates() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val fusedLocationClient = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(this@MainActivity)
                val locationRequest = com.google.android.gms.location.LocationRequest.create().apply {
                    priority = com.google.android.gms.location.LocationRequest.PRIORITY_HIGH_ACCURACY
                    interval = 10000
                    fastestInterval = 5000
                }
                fusedLocationClient.requestLocationUpdates(locationRequest, object : com.google.android.gms.location.LocationCallback() {
                    override fun onLocationResult(result: com.google.android.gms.location.LocationResult) {
                        result.lastLocation?.let {
                            currentLocation = it
                            locationState.value = it
                        }
                    }
                }, Looper.getMainLooper())
            } catch (e: Exception) {
                Log.e("Stargazer", "Location error", e)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        accelerometer?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        magnetometer?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event?.let {
            when (it.sensor.type) {
                Sensor.TYPE_ACCELEROMETER -> gravity = it.values.clone()
                Sensor.TYPE_MAGNETIC_FIELD -> geomagnetic = it.values.clone()
            }
            gravity?.let { g ->
                geomagnetic?.let { m ->
                    val R = FloatArray(9)
                    val I = FloatArray(9)
                    if (SensorManager.getRotationMatrix(R, I, g, m)) {
                        val orientation = FloatArray(3)
                        SensorManager.getOrientation(R, orientation)
                        azimuth = (orientation[0] * 180 / PI).toFloat()
                        if (azimuth < 0) azimuth += 360f
                        azimuthState.value = azimuth
                    }
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    @Composable
    fun StargazerTheme() {
        val azimuth by azimuthState
        val location by locationState
        val time = remember { mutableStateOf(Date()) }
        val redMode = remember { mutableStateOf(false) }

        // Update time every second
        remember { Handler(Looper.getMainLooper()).run {
            postDelayed({ time.value = Date(); postDelayed(this, 1000) }, 1000)
        } }

        val issPass = remember { mutableStateOf<IssPass?>(null) }
        val celestialObjects = remember { computeCelestialObjects(location, time.value) }

        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Header with compass heading
            Box(
                modifier = Modifier.fillMaxSize().weight(1f),
                contentAlignment = Alignment.Center
            ) {
                SkyView(
                    azimuth = azimuth,
                    celestialObjects = celestialObjects,
                    redMode = redMode.value,
                    location = location
                )

                // Compass ring overlay
                CompassRing(azimuth = azimuth)
            }

            // Bottom info bar
            Card(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                colors = androidx.wear.compose.material.CardDefaults.cardColors(
                    containerColor = if (redMode.value) Color(0xFF330000) else Color(0xFF1A1A2E)
                )
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = formatTime(time.value),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (redMode.value) Color(0xFFFF6666) else Color.White
                        )
                        Text(
                            text = "AZ ${azimuth.toInt()}°",
                            fontSize = 12.sp,
                            color = if (redMode.value) Color(0xFFFF6666) else Color.White.copy(alpha = 0.7f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        location?.let { loc ->
                            Text(
                                text = String.format(Locale.getDefault(), "%.4f°, %.4f°", loc.latitude, loc.longitude),
                                fontSize = 10.sp,
                                color = if (redMode.value) Color(0xFFFF6666) else Color.White.copy(alpha = 0.6f)
                            )
                        }
                        Text(
                            text = issPass.value?.let { "ISS in ${formatDuration(it.riseTime - System.currentTimeMillis())}" } ?: "ISS: calculating...",
                            fontSize = 10.sp,
                            color = if (redMode.value) Color(0xFFFF6666) else Color.White.copy(alpha = 0.6f)
                        )
                    }
                }
            }

            // Control chips
            Row(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Chip(
                    onClick = { redMode.value = !redMode.value },
                    label = { Text(if (redMode.value) "🔴 Red ON" else "⚪ Red OFF") },
                    colors = androidx.wear.compose.material.ChipDefaults.colors(
                        containerColor = if (redMode.value) Color(0xFF660000) else Color(0xFF2A2A3E)
                    )
                )
                Chip(
                    onClick = { /* Recenter */ },
                    label = { Text("🔄 Recenter") },
                    colors = androidx.wear.compose.material.ChipDefaults.colors(containerColor = Color(0xFF2A2A3E))
                )
            }
        }
    }

    private fun formatTime(date: Date): String {
        return SimpleDateFormat("HH:mm:ss", Locale.getDefault()).apply { timeZone = TimeZone.getDefault() }.format(date)
    }

    private fun formatDuration(ms: Long): String {
        val seconds = ms / 1000
        val minutes = seconds / 60
        val hours = minutes / 60
        return when {
            hours > 0 -> "${hours}h ${minutes % 60}m"
            minutes > 0 -> "${minutes}m ${seconds % 60}s"
            else -> "${seconds}s"
        }
    }

    data class CelestialObject(
        val name: String,
        val azimuth: Float,
        val altitude: Float,
        val magnitude: Float,
        val type: Type,
        val color: Int
    ) {
        enum class Type { SUN, MOON, PLANET, STAR, ISS, CONSTELLATION }
    }

    data class IssPass(val riseTime: Long, val maxAltitude: Float, val setTime: Long)

    private fun computeCelestialObjects(location: Location?, time: Date): List<CelestialObject> {
        val objects = mutableListOf<CelestialObject>()
        val loc = location ?: return objects
        val jd = julianDate(time)
        val lat = loc.latitude
        val lon = loc.longitude

        // Sun
        val sunPos = sunPosition(jd)
        val sunAltAz = equatorialToHorizontal(sunPos.ra, sunPos.dec, lat, lon, jd)
        objects.add(CelestialObject("☀️ Sun", sunAltAz.azimuth, sunAltAz.altitude, -26.7f, CelestialObject.Type.SUN, 0xFFFFD700))

        // Moon
        val moonPos = moonPosition(jd)
        val moonAltAz = equatorialToHorizontal(moonPos.ra, moonPos.dec, lat, lon, jd)
        objects.add(CelestialObject("🌙 Moon", moonAltAz.azimuth, moonAltAz.altitude, -12.7f, CelestialObject.Type.MOON, 0xFFF5F5DC))

        // Planets (simplified positions)
        listOf(
            "Mercury" to 0.4f to 0xFFB5B5B5,
            "Venus" to -4.4f to 0xFFE6C87A,
            "Mars" to -2.0f to 0xFFFF4500,
            "Jupiter" to -2.5f to 0xFFF0E68C,
            "Saturn" to 0.5f to 0xFFF4D59E
        ).forEach { (name, mag, color) ->
            val planetPos = planetPosition(name, jd)
            val altAz = equatorialToHorizontal(planetPos.ra, planetPos.dec, lat, lon, jd)
            objects.add(CelestialObject(name, altAz.azimuth, altAz.altitude, mag, CelestialObject.Type.PLANET, color))
        }

        // Bright stars
        listOf(
            "Sirius" to 101.29 to -16.72 to -1.46f,
            "Canopus" to 264.01 to -52.70 to -0.74f,
            "Arcturus" to 213.91 to 19.18 to -0.05f,
            "Vega" to 279.23 to 38.78 to 0.03f,
            "Capella" to 79.17 to 45.99 to 0.08f,
            "Rigel" to 78.63 to -8.20 to 0.13f,
            "Procyon" to 114.83 to 5.22 to 0.34f,
            "Betelgeuse" to 88.79 to 7.41 to 0.50f
        ).forEach { (name, ra, dec, mag) ->
            val altAz = equatorialToHorizontal(ra, dec, lat, lon, jd)
            objects.add(CelestialObject(name, altAz.azimuth, altAz.altitude, mag, CelestialObject.Type.STAR, 0xFFFFFFFF))
        }

        // ISS (simplified - would need TLE in real app)
        if (currentLocation != null) {
            val issPass = computeIssPass(currentLocation!!, time)
            this.issPass.value = issPass
            if (issPass != null) {
                val issPos = issPosition(issPass, time.time)
                val issAltAz = equatorialToHorizontal(issPos.ra, issPos.dec, lat, lon, jd)
                objects.add(CelestialObject("🛰️ ISS", issAltAz.azimuth, issAltAz.altitude, -3.0f, CelestialObject.Type.ISS, 0xFF00FFFF))
            }
        }

        return objects.filter { it.altitude > -5f } // Only above horizon (with small margin)
    }

    private fun julianDate(date: Date): Double {
        val time = date.time / 1000.0 / 86400.0 + 2440587.5
        return time
    }

    data class EqPos(val ra: Double, val dec: Double)

    private fun sunPosition(jd: Double): EqPos {
        val n = jd - 2451545.0
        val L = (280.460 + 0.9856474 * n) % 360
        val g = Math.toRadians((357.528 + 0.9856003 * n) % 360)
        val lambda = Math.toRadians(L + 1.915 * sin(g) + 0.020 * sin(2 * g))
        val epsilon = Math.toRadians(23.439 - 0.0000004 * n)
        val ra = atan2(cos(epsilon) * sin(lambda), cos(lambda))
        val dec = asin(sin(epsilon) * sin(lambda))
        return EqPos(ra, dec)
    }

    private fun moonPosition(jd: Double): EqPos {
        val n = jd - 2451545.0
        val L = (218.316 + 13.176396 * n) % 360
        val M = (134.963 + 13.064993 * n) % 360
        val F = (93.272 + 13.229350 * n) % 360
        val lambda = L + 6.289 * sin(Math.toRadians(M)) + 1.274 * sin(Math.toRadians(2 * (L - F) - M))
        val beta = 5.128 * sin(Math.toRadians(F))
        val epsilon = Math.toRadians(23.439 - 0.0000004 * n)
        val ra = atan2(cos(epsilon) * sin(Math.toRadians(lambda)) + sin(epsilon) * tan(Math.toRadians(beta)), cos(Math.toRadians(lambda)))
        val dec = asin(sin(epsilon) * sin(Math.toRadians(lambda)) + cos(epsilon) * sin(Math.toRadians(beta)))
        return EqPos(ra, dec)
    }

    private fun planetPosition(name: String, jd: Double): EqPos {
        // Very simplified - real app would use VSOP87 or similar
        val n = jd - 2451545.0
        val (period, offset) = when (name) {
            "Mercury" -> 87.97 to 0.0
            "Venus" -> 224.7 to 0.0
            "Mars" -> 687.0 to 0.0
            "Jupiter" -> 4332.6 to 0.0
            "Saturn" -> 10759.2 to 0.0
            else -> 365.25 to 0.0
        }
        val angle = (360.0 * n / period + offset) % 360
        val ra = Math.toRadians(angle)
        val dec = Math.toRadians(0.0) // Simplified: ecliptic plane
        return EqPos(ra, dec)
    }

    private fun equatorialToHorizontal(ra: Double, dec: Double, lat: Double, lon: Double, jd: Double): EqPos {
        val lst = (280.46061837 + 360.98564736629 * (jd - 2451545.0) + lon) % 360
        val ha = Math.toRadians(lst - Math.toDegrees(ra))
        val latRad = Math.toRadians(lat)
        val altitude = asin(sin(latRad) * sin(dec) + cos(latRad) * cos(dec) * cos(ha))
        val azimuth = atan2(sin(ha), cos(ha) * sin(latRad) - tan(dec) * cos(latRad))
        var azDeg = Math.toDegrees(azimuth)
        if (azDeg < 0) azDeg += 360
        return EqPos(Math.toRadians(azDeg), altitude)
    }

    private fun issPosition(pass: IssPass, now: Long): EqPos {
        // Interpolate ISS position during pass
        val progress = (now - pass.riseTime).toDouble() / (pass.setTime - pass.riseTime)
        val alt = pass.maxAltitude * sin(progress * PI)
        // Simplified RA/Dec from altitude/azimuth
        return EqPos(0.0, Math.toRadians(alt))
    }

    private fun computeIssPass(location: Location, now: Date): IssPass? {
        // Simplified: next pass roughly 90 minutes from now, max altitude random
        val rise = now.time + 5 * 60 * 1000 // 5 min from now
        val maxAlt = (45 + Math.random() * 45).toFloat()
        val set = rise + 10 * 60 * 1000 // 10 min duration
        return IssPass(rise, maxAlt, set)
    }
}

@Composable
fun SkyView(
    azimuth: Float,
    celestialObjects: List<MainActivity.CelestialObject>,
    redMode: Boolean,
    location: Location?
) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val centerX = size.width / 2f
        val centerY = size.height / 2f
        val radius = minOf(centerX, centerY) * 0.9f

        // Background
        drawRect(
            color = if (redMode) Color(0xFF1A0000) else Color(0xFF0A0A1A),
            size = size
        )

        // Stars (dimmed for red mode)
        val starColor = if (redMode) Color(0xFF662222) else Color.White.copy(alpha = 0.3f)
        (1..50).forEach { i ->
            val angle = (i * 137.5f) % 360 * PI / 180
            val r = radius * (0.2f + (i % 7) * 0.1f)
            val x = centerX + r * cos(angle)
            val y = centerY + r * sin(angle)
            drawCircle(starColor, radius = 1f, center = androidx.compose.ui.geometry.Offset(x, y))
        }

        // Draw celestial objects
        celestialObjects.forEach { obj ->
            val relAzimuth = (obj.azimuth - azimuth + 360) % 360
            val angle = (relAzimuth - 90) * PI / 180 // -90 to put North at top
            val altFactor = maxOf(0f, (obj.altitude + 90) / 180) // 0 at horizon, 1 at zenith
            val r = radius * (1 - altFactor * 0.85f)
            val x = centerX + r * cos(angle)
            val y = centerY + r * sin(angle)

            val objColor = if (redMode) Color(0xFFFF4444) else Color(obj.color)
            val size = when (obj.type) {
                MainActivity.CelestialObject.Type.SUN -> 16f
                MainActivity.CelestialObject.Type.MOON -> 14f
                MainActivity.CelestialObject.Type.PLANET -> 10f
                MainActivity.CelestialObject.Type.ISS -> 12f
                else -> maxOf(4f, 8f - obj.magnitude)
            }

            // Glow for bright objects
            if (obj.magnitude < 0) {
                drawCircle(objColor.copy(alpha = 0.3f), radius = size * 2, center = androidx.compose.ui.geometry.Offset(x, y))
            }
            drawCircle(objColor, radius = size, center = androidx.compose.ui.geometry.Offset(x, y))

            // Label for bright objects
            if (obj.magnitude < 1.0 || obj.type == MainActivity.CelestialObject.Type.ISS) {
                // Text drawing would need DrawScope.drawText - simplified for now
            }
        }

        // Horizon line
        val horizonRadius = radius
        drawCircle(Color.White.copy(alpha = 0.1f), radius = horizonRadius, style = androidx.compose.ui.graphics.Stroke(width = 1f), center = androidx.compose.ui.geometry.Offset(centerX, centerY))

        // Cardinal directions
        listOf("N" to 0f, "E" to 90f, "S" to 180f, "W" to 270f).forEach { (label, deg) ->
            val angle = (deg - azimuth - 90) * PI / 180
            val r = radius * 1.05f
            val x = centerX + r * cos(angle)
            val y = centerY + r * sin(angle)
            // Would draw text here
        }
    }
}

@Composable
fun CompassRing(azimuth: Float) {
    Canvas(modifier = Modifier.size(200.dp)) {
        val centerX = size.width / 2f
        val centerY = size.height / 2f
        val radius = minOf(centerX, centerY)

        // Tick marks
        (0..359 step 15).forEach { deg ->
            val angle = (deg - azimuth - 90) * PI / 180
            val isMajor = deg % 90 == 0
            val innerR = radius - (if (isMajor) 20f else 10f)
            val outerR = radius
            val x1 = centerX + innerR * cos(angle)
            val y1 = centerY + innerR * sin(angle)
            val x2 = centerX + outerR * cos(angle)
            val y2 = centerY + outerR * sin(angle)
            drawLine(
                color = Color.White.copy(alpha = if (isMajor) 0.6f else 0.2f),
                start = androidx.compose.ui.geometry.Offset(x1, y1),
                end = androidx.compose.ui.geometry.Offset(x2, y2),
                strokeWidth = if (isMajor) 2f else 1f
            )
        }
    }
}