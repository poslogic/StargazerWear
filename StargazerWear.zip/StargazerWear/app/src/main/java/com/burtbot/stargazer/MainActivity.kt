package com.burtbot.stargazer

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.Text
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class MainActivity : ComponentActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private lateinit var locationManager: LocationManager
    private var rotationSensor: Sensor? = null

    private val headingState = mutableStateOf(0f)
    private val locationState = mutableStateOf<Location?>(null)

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            locationState.value = location
        }
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startLocation()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

        setContent {
            StargazerApp(headingState.value, locationState.value)
        }
    }

    override fun onResume() {
        super.onResume()
        rotationSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
        if (hasLocationPermission()) {
            startLocation()
        } else {
            permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
        try {
            locationManager.removeUpdates(locationListener)
        } catch (e: SecurityException) {
            // permission revoked; nothing to remove
        }
    }

    private fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun startLocation() {
        try {
            val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            for (provider in providers) {
                if (locationManager.isProviderEnabled(provider)) {
                    val last = locationManager.getLastKnownLocation(provider)
                    if (last != null && locationState.value == null) {
                        locationState.value = last
                    }
                    locationManager.requestLocationUpdates(provider, 10000L, 10f, locationListener)
                }
            }
        } catch (e: SecurityException) {
            // ignore: user denied permission
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
        val rotation = FloatArray(9)
        SensorManager.getRotationMatrixFromVector(rotation, event.values)
        val orientation = FloatArray(3)
        SensorManager.getOrientation(rotation, orientation)
        var degrees = Math.toDegrees(orientation[0].toDouble()).toFloat()
        if (degrees < 0f) degrees += 360f
        headingState.value = degrees
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

@Composable
fun StargazerApp(heading: Float, location: Location?) {
    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    var redMode by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000L)
            nowMs = System.currentTimeMillis()
        }
    }

    val bodies = if (location == null) {
        emptyList()
    } else {
        Astro.visibleBodies(nowMs / 5000L * 5000L, location.latitude, location.longitude)
    }

    val fg = if (redMode) Color(0xFFFF4444) else Color.White
    val bg = if (redMode) Color(0xFF1A0000) else Color(0xFF0A0A1A)

    MaterialTheme {
        Box(
            modifier = Modifier.fillMaxSize().background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            SkyView(heading = heading, bodies = bodies, fg = fg, bg = bg, redMode = redMode)

            Column(
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(nowMs))
                Text(text = "$time  HDG ${heading.toInt()}\u00B0", color = fg, fontSize = 11.sp)
                Text(
                    text = if (location == null) "Waiting for location..."
                    else String.format(Locale.US, "%.3f, %.3f", location.latitude, location.longitude),
                    color = fg.copy(alpha = 0.7f),
                    fontSize = 9.sp
                )
                Text(
                    text = if (redMode) "Red mode: ON" else "Red mode: OFF",
                    color = fg,
                    fontSize = 10.sp,
                    modifier = Modifier.clickable { redMode = !redMode }.padding(6.dp)
                )
            }
        }
    }
}

@Composable
fun SkyView(heading: Float, bodies: List<Astro.Body>, fg: Color, bg: Color, redMode: Boolean) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val radius = min(cx, cy) * 0.88f
        val center = Offset(cx, cy)

        drawCircle(color = bg, radius = radius, center = center)
        drawCircle(color = fg.copy(alpha = 0.5f), radius = radius, center = center, style = Stroke(width = 2f))
        drawCircle(color = fg.copy(alpha = 0.15f), radius = radius * 0.667f, center = center, style = Stroke(width = 1f))
        drawCircle(color = fg.copy(alpha = 0.15f), radius = radius * 0.333f, center = center, style = Stroke(width = 1f))

        val labelPaint = Paint().apply {
            color = fg.toArgb()
            textSize = 24f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        val smallPaint = Paint().apply {
            color = fg.copy(alpha = 0.8f).toArgb()
            textSize = 18f
            isAntiAlias = true
            textAlign = Paint.Align.LEFT
        }
        val canvas = drawContext.canvas.nativeCanvas

        // Compass letters around the rim, rotating with the watch heading
        val cardinals = listOf("N" to 0f, "E" to 90f, "S" to 180f, "W" to 270f)
        for (entry in cardinals) {
            val rel = Math.toRadians((entry.second - heading).toDouble())
            val r = radius * 0.9f
            val x = cx + r * sin(rel).toFloat()
            val y = cy - r * cos(rel).toFloat() + 8f
            canvas.drawText(entry.first, x, y, labelPaint)
        }

        // Sky objects: zenith at centre, horizon at the edge, heading points up
        for (b in bodies) {
            val rel = Math.toRadians(b.az - heading)
            val r = radius * ((90.0 - b.alt) / 90.0).toFloat()
            val x = cx + r * sin(rel).toFloat()
            val y = cy - r * cos(rel).toFloat()
            val color = if (redMode) Color(0xFFFF6666) else Color(b.color)
            drawCircle(color = color, radius = b.radius, center = Offset(x, y))
            if (b.labelled) {
                canvas.drawText(b.name, x + b.radius + 4f, y + 6f, smallPaint)
            }
        }
    }
}
