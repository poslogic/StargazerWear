package com.burtbot.stargazer

import android.Manifest
import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.Text
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

class MainActivity : ComponentActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private lateinit var locationManager: LocationManager
    private lateinit var prefs: SharedPreferences
    private var rotationSensor: Sensor? = null

    val headingState = mutableStateOf(0f)
    val locationState = mutableStateOf<Location?>(null)
    val idleSecs = mutableStateOf(60)
    val alertOn = mutableStateOf(false)
    val flipOn = mutableStateOf(true)
    val showMask = mutableStateOf(SHOW_ALL)
    val textIdx = mutableStateOf(1)
    val passes = mutableStateOf<List<Pass>>(emptyList())
    val status = mutableStateOf("Waiting for location...")

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    @Volatile private var computing = false
    private var lastComputeMs = 0L
    private var lastLat = 999.0
    private var lastLon = 999.0

    private val idleHandler = Handler(Looper.getMainLooper())
    private val idleRunnable = Runnable {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            handleLocation(location)
        }
    }

    private val locationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startLocation()
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        prefs = Prefs.get(this)

        idleSecs.value = prefs.getInt("idle_secs", 60)
        alertOn.value = prefs.getBoolean("alert_on", false)
        flipOn.value = prefs.getBoolean("flip_on", true)
        showMask.value = if (prefs.contains("show_mask")) {
            prefs.getInt("show_mask", SHOW_ALL) and SHOW_ALL
        } else {
            // migrate the old single-choice filter
            when (prefs.getInt("filter_idx", 0)) {
                1 -> SHOW_SUN_MOON
                2 -> SHOW_PLANETS
                3 -> SHOW_STARS
                4 -> SHOW_SATELLITES
                else -> SHOW_ALL
            }
        }
        textIdx.value = prefs.getInt("text_idx", 1).coerceIn(0, TEXT_LABELS.size - 1)

        val savedLat = prefs.getString("lat", null)?.toDoubleOrNull()
        val savedLon = prefs.getString("lon", null)?.toDoubleOrNull()
        if (savedLat != null && savedLon != null) {
            val saved = Location("saved")
            saved.latitude = savedLat
            saved.longitude = savedLon
            locationState.value = saved
        }
        val now = System.currentTimeMillis()
        passes.value = PassStore.load(this).filter { it.endMs > now }
        scope.launch { PassRepo.loadOrbits(applicationContext) }

        setContent { StargazerApp(this) }
    }

    override fun onResume() {
        super.onResume()
        rotationSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            startLocation()
        } else {
            locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        applyIdle()
        maybeRefresh()
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
        idleHandler.removeCallbacks(idleRunnable)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try {
            locationManager.removeUpdates(locationListener)
        } catch (e: SecurityException) {
            // permission revoked
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        applyIdle()
    }

    /** Keeps the screen awake until the chosen idle time has passed with no touches. */
    private fun applyIdle() {
        idleHandler.removeCallbacks(idleRunnable)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val s = idleSecs.value
        if (s > 0) idleHandler.postDelayed(idleRunnable, s * 1000L)
    }

    @SuppressLint("MissingPermission")
    private fun startLocation() {
        try {
            val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            for (provider in providers) {
                if (locationManager.isProviderEnabled(provider)) {
                    val last = locationManager.getLastKnownLocation(provider)
                    if (last != null) handleLocation(last)
                    locationManager.requestLocationUpdates(provider, 10000L, 10f, locationListener)
                }
            }
        } catch (e: SecurityException) {
            // user denied permission
        }
    }

    private fun handleLocation(location: Location) {
        locationState.value = location
        prefs.edit()
            .putString("lat", location.latitude.toString())
            .putString("lon", location.longitude.toString())
            .apply()
        maybeRefresh()
    }

    private fun maybeRefresh() {
        val loc = locationState.value ?: return
        val moved = abs(loc.latitude - lastLat) > 0.2 || abs(loc.longitude - lastLon) > 0.2
        val stale = System.currentTimeMillis() - lastComputeMs > 30L * 60L * 1000L
        if (moved || stale) refreshPasses(false)
    }

    fun refreshPasses(force: Boolean) {
        val loc = locationState.value
        if (loc == null) {
            status.value = "Waiting for location..."
            return
        }
        if (computing) return
        computing = true
        status.value = "Updating satellite data..."
        val lat = loc.latitude
        val lon = loc.longitude
        scope.launch {
            try {
                TleStore.refresh(applicationContext, force)
                PassRepo.loadOrbits(applicationContext)
                val list = PassRepo.recompute(applicationContext, lat, lon, true)
                passes.value = list
                lastComputeMs = System.currentTimeMillis()
                lastLat = lat
                lastLon = lon
                status.value = if (SatCache.iss == null) {
                    "No satellite data. Check Wi-Fi or phone link, then refresh."
                } else if (list.isEmpty()) {
                    "No visible passes in the next 3 days."
                } else {
                    ""
                }
                AlertScheduler.scheduleNext(applicationContext)
                WidgetUpdater.requestAll(applicationContext)
            } catch (e: Exception) {
                status.value = "Update failed."
            } finally {
                computing = false
            }
        }
    }

    fun cycleIdle() {
        val opts = IDLE_OPTIONS
        val idx = opts.indexOf(idleSecs.value)
        idleSecs.value = opts[(idx + 1) % opts.size]
        prefs.edit().putInt("idle_secs", idleSecs.value).apply()
        applyIdle()
    }

    fun toggleShow(bit: Int) {
        showMask.value = showMask.value xor bit
        prefs.edit().putInt("show_mask", showMask.value).apply()
    }

    fun cycleTextSize() {
        textIdx.value = (textIdx.value + 1) % TEXT_LABELS.size
        prefs.edit().putInt("text_idx", textIdx.value).apply()
    }

    fun toggleFlip() {
        flipOn.value = !flipOn.value
        prefs.edit().putBoolean("flip_on", flipOn.value).apply()
    }

    fun toggleAlert() {
        alertOn.value = !alertOn.value
        prefs.edit().putBoolean("alert_on", alertOn.value).apply()
        if (alertOn.value && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        AlertScheduler.scheduleNext(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
        val rotation = FloatArray(9)
        SensorManager.getRotationMatrixFromVector(rotation, event.values)
        val orientation = FloatArray(3)
        SensorManager.getOrientation(rotation, orientation)
        var degrees = Math.toDegrees(orientation[0].toDouble()).toFloat()
        if (degrees < 0f) degrees += 360f
        headingState.value = degrees
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    companion object {
        val IDLE_OPTIONS = intArrayOf(15, 30, 60, 120, 300, 0)
        const val SHOW_SUN_MOON = 1
        const val SHOW_PLANETS = 2
        const val SHOW_STARS = 4
        const val SHOW_SATELLITES = 8
        const val SHOW_ALL = 15
        val TEXT_LABELS = arrayOf("Small", "Normal", "Large", "Extra large")
        val TEXT_SCALES = floatArrayOf(0.85f, 1.0f, 1.2f, 1.4f)
    }
}

// ---------------------------------------------------------------- helpers

private val ISS_COLOR = Color(0xFF2EE6FF)
private val STARLINK_COLOR = Color(0xFFFF6BFF)
private val GPS_COLOR = Color(0xFF39FF14)

fun kindMatches(kind: String, mask: Int): Boolean = when (kind) {
    "sun", "moon" -> mask and MainActivity.SHOW_SUN_MOON != 0
    "planet" -> mask and MainActivity.SHOW_PLANETS != 0
    "star" -> mask and MainActivity.SHOW_STARS != 0
    "iss", "starlink" -> mask and MainActivity.SHOW_SATELLITES != 0
    else -> true
}

fun idleLabel(s: Int): String = when {
    s == 0 -> "Always on"
    s < 60 -> "$s sec"
    else -> "${s / 60} min"
}

fun clock(ms: Long?): String =
    if (ms == null) "--:--" else SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ms))

fun startOfDay(ms: Long): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun dayLabel(ms: Long, nowMs: Long): String {
    val a = Calendar.getInstance()
    a.timeInMillis = ms
    val b = Calendar.getInstance()
    b.timeInMillis = nowMs
    if (a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)) {
        return "Today"
    }
    b.add(Calendar.DAY_OF_YEAR, 1)
    if (a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)) {
        return "Tomorrow"
    }
    return SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(Date(ms))
}

fun nextIssText(passes: List<Pass>, nowMs: Long): String {
    val p = passes.filter { it.name == "ISS" && it.endMs > nowMs }.minByOrNull { it.startMs }
        ?: return "ISS: no pass soon"
    if (p.startMs <= nowMs) return "ISS visible now!"
    val mins = (p.startMs - nowMs) / 60000L
    return if (mins >= 60) "ISS in ${mins / 60}h ${mins % 60}m" else "ISS in ${mins}m"
}

// ---------------------------------------------------------------- UI

@Composable
fun StargazerApp(act: MainActivity) {
    val heading by act.headingState
    val location by act.locationState
    val passes by act.passes
    val status by act.status
    val idleSecs by act.idleSecs
    val alertOn by act.alertOn
    val flipOn by act.flipOn
    val showMask by act.showMask
    val textIdx by act.textIdx

    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    var redMode by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000L)
            nowMs = System.currentTimeMillis()
        }
    }

    val fg = if (redMode) Color(0xFFFF5555) else Color.White
    val scope = rememberCoroutineScope()
    val hState = rememberPagerState(initialPage = 0, pageCount = { 1 + Astro.pageBodies.size })
    val vState = rememberPagerState(initialPage = 1, pageCount = { 3 })

    BackHandler(enabled = hState.currentPage != 0 || vState.currentPage != 1) {
        scope.launch {
            hState.animateScrollToPage(0)
            vState.animateScrollToPage(1)
        }
    }

    val baseDensity = LocalDensity.current
    val scaledDensity = Density(baseDensity.density, baseDensity.fontScale * MainActivity.TEXT_SCALES[textIdx])

    CompositionLocalProvider(LocalDensity provides scaledDensity) {
    MaterialTheme {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            HorizontalPager(state = hState, modifier = Modifier.fillMaxSize()) { page ->
                if (page == 0) {
                    VerticalPager(state = vState, modifier = Modifier.fillMaxSize()) { vp ->
                        when (vp) {
                            0 -> SettingsScreen(
                                idleText = idleLabel(idleSecs),
                                showMask = showMask,
                                textSizeText = MainActivity.TEXT_LABELS[textIdx],
                                alertOn = alertOn,
                                flipOn = flipOn,
                                fg = fg,
                                status = status,
                                onIdle = { act.cycleIdle() },
                                onShow = { act.toggleShow(it) },
                                onTextSize = { act.cycleTextSize() },
                                onAlert = { act.toggleAlert() },
                                onFlip = { act.toggleFlip() },
                                onRefresh = { act.refreshPasses(true) }
                            )
                            1 -> SkyScreen(
                                heading = heading,
                                location = location,
                                nowMs = nowMs,
                                flip = flipOn,
                                redMode = redMode,
                                passes = passes,
                                filter = showMask,
                                onToggleRed = { redMode = !redMode }
                            )
                            else -> PassesScreen(passes = passes, status = status, nowMs = nowMs, fg = fg)
                        }
                    }
                } else {
                    PlanetPage(
                        name = Astro.pageBodies[page - 1],
                        location = location,
                        nowMs = nowMs,
                        fg = fg
                    )
                }
            }
        }
    }
    }
}

@Composable
fun SkyScreen(
    heading: Float,
    location: Location?,
    nowMs: Long,
    flip: Boolean,
    redMode: Boolean,
    passes: List<Pass>,
    filter: Int,
    onToggleRed: () -> Unit
) {
    val fg = if (redMode) Color(0xFFFF5555) else Color.White
    val bg = if (redMode) Color(0xFF1A0000) else Color(0xFF0A0A1A)

    val bodies = remember(nowMs / 5000L, location) {
        if (location == null) {
            emptyList<Astro.Body>()
        } else {
            val t = nowMs / 5000L * 5000L
            Astro.visibleBodies(t, location.latitude, location.longitude) +
                SatSky.bodies(t, location.latitude, location.longitude)
        }
    }

    val shown = remember(bodies, filter) { bodies.filter { kindMatches(it.kind, filter) } }
    var selected by remember { mutableStateOf<Astro.Body?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        SkyView(
            heading = heading,
            bodies = shown,
            fg = fg,
            bg = bg,
            redMode = redMode,
            flip = flip,
            onSelect = { selected = it }
        )

        Text(
            text = if (location == null) "Waiting for GPS..."
            else String.format(Locale.US, "%.3f, %.3f", location.latitude, location.longitude),
            color = if (redMode) fg else GPS_COLOR,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 20.dp)
        )

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 10.dp)
                .background(Color(0x99000000)),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(nowMs))
            Text(text = "$time   HDG ${heading.toInt()}\u00B0", color = fg, fontSize = 14.sp)
            Text(
                text = nextIssText(passes, nowMs),
                color = if (redMode) fg else ISS_COLOR,
                fontSize = 13.sp
            )
            Text(
                text = if (redMode) "Red mode: ON" else "Red mode: OFF",
                color = fg,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { onToggleRed() }.padding(horizontal = 8.dp, vertical = 5.dp)
            )
        }

        val sel = selected
        if (sel != null && location != null) {
            InfoOverlay(
                body = sel,
                lat = location.latitude,
                lon = location.longitude,
                nowMs = nowMs,
                passes = passes,
                redMode = redMode,
                onDismiss = { selected = null }
            )
        }
    }
}

private const val SKY_RADIUS_FRACTION = 0.72f

private fun projectBody(b: Astro.Body, heading: Float, flip: Boolean, cx: Float, cy: Float, radius: Float): Offset {
    val sign = if (flip) -1f else 1f
    val rel = Math.toRadians(b.az - heading)
    val r = radius * ((90.0 - b.alt) / 90.0).toFloat()
    return Offset(cx + sign * r * sin(rel).toFloat(), cy - sign * r * cos(rel).toFloat())
}

@Composable
fun SkyView(
    heading: Float,
    bodies: List<Astro.Body>,
    fg: Color,
    bg: Color,
    redMode: Boolean,
    flip: Boolean,
    onSelect: (Astro.Body?) -> Unit
) {
    val headingNow = rememberUpdatedState(heading)
    val bodiesNow = rememberUpdatedState(bodies)
    val flipNow = rememberUpdatedState(flip)

    Canvas(
        modifier = Modifier.fillMaxSize().pointerInput(Unit) {
            detectTapGestures { tap ->
                val cx = size.width / 2f
                val cy = size.height / 2f
                val radius = min(cx, cy) * SKY_RADIUS_FRACTION
                var best: Astro.Body? = null
                var bestDist = 30.dp.toPx()
                for (b in bodiesNow.value) {
                    val p = projectBody(b, headingNow.value, flipNow.value, cx, cy, radius)
                    var d = hypot(tap.x - p.x, tap.y - p.y)
                    if (b.kind == "starlink") d += 14.dp.toPx()
                    if (d < bestDist) {
                        bestDist = d
                        best = b
                    }
                }
                onSelect(best)
            }
        }
    ) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val radius = min(cx, cy) * SKY_RADIUS_FRACTION
        val center = Offset(cx, cy)
        val sign = if (flip) -1f else 1f

        drawCircle(color = bg, radius = radius, center = center)
        drawCircle(color = fg.copy(alpha = 0.5f), radius = radius, center = center, style = Stroke(width = 2f))
        drawCircle(color = fg.copy(alpha = 0.15f), radius = radius * 0.667f, center = center, style = Stroke(width = 1f))
        drawCircle(color = fg.copy(alpha = 0.15f), radius = radius * 0.333f, center = center, style = Stroke(width = 1f))

        val cardinalPaint = Paint().apply {
            color = fg.toArgb()
            textSize = 20.sp.toPx()
            isAntiAlias = true
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val labelPaint = Paint().apply {
            textSize = 15.sp.toPx()
            isAntiAlias = true
            textAlign = Paint.Align.LEFT
        }
        val canvas = drawContext.canvas.nativeCanvas

        val cardinals = listOf("N" to 0f, "E" to 90f, "S" to 180f, "W" to 270f)
        for (entry in cardinals) {
            val rel = Math.toRadians((entry.second - heading).toDouble())
            val r = radius * 1.12f
            val x = cx + sign * r * sin(rel).toFloat()
            val y = cy - sign * r * cos(rel).toFloat() + 7.sp.toPx()
            canvas.drawText(entry.first, x, y, cardinalPaint)
        }

        for (b in bodies) {
            val p = projectBody(b, heading, flip, cx, cy, radius)
            val color = if (redMode) Color(0xFFFF6666) else Color(b.color)
            drawCircle(color = color, radius = b.radius.dp.toPx() * 0.8f, center = p)
            if (b.labelled) {
                labelPaint.textSize = if (b.kind == "star") 11.sp.toPx() else 15.sp.toPx()
                labelPaint.color = color.toArgb()
                canvas.drawText(b.name, p.x + b.radius.dp.toPx() + 3.dp.toPx(), p.y + 5.dp.toPx(), labelPaint)
            }
        }
    }
}

@Composable
fun PassesScreen(passes: List<Pass>, status: String, nowMs: Long, fg: Color) {
    val upcoming = passes.filter { it.endMs > nowMs }.sortedBy { it.startMs }.take(4)
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 26.dp, vertical = 22.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Next passes", color = fg, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        if (upcoming.isEmpty()) {
            Text(
                text = if (status.isEmpty()) "No visible passes soon." else status,
                color = fg.copy(alpha = 0.8f),
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
        for (p in upcoming) {
            val color = if (fg == Color.White) {
                if (p.name == "ISS") ISS_COLOR else STARLINK_COLOR
            } else {
                fg
            }
            val label = if (p.name == "Starlink" && p.count > 1) "Starlink x${p.count}" else p.name
            val mins = maxOf(1L, (p.endMs - p.startMs + 30000L) / 60000L)
            Text(
                text = "$label  ${dayLabel(p.startMs, nowMs)} ${clock(p.startMs)}",
                color = color,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 5.dp)
            )
            Text(
                text = "max ${p.maxEl.toInt()}\u00B0  ${compassName(p.startAz)} to ${compassName(p.endAz)}  ${mins}m",
                color = fg.copy(alpha = 0.75f),
                fontSize = 11.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun SettingsScreen(
    idleText: String,
    showMask: Int,
    textSizeText: String,
    alertOn: Boolean,
    flipOn: Boolean,
    fg: Color,
    status: String,
    onIdle: () -> Unit,
    onShow: (Int) -> Unit,
    onTextSize: () -> Unit,
    onAlert: () -> Unit,
    onFlip: () -> Unit,
    onRefresh: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(top = 34.dp, bottom = 34.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Settings", color = fg.copy(alpha = 0.6f), fontSize = 11.sp)
        Text(text = "Show on sky", color = fg.copy(alpha = 0.6f), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        ShowRow("Sun & Moon", MainActivity.SHOW_SUN_MOON, showMask, fg, onShow)
        ShowRow("Planets", MainActivity.SHOW_PLANETS, showMask, fg, onShow)
        ShowRow("Stars", MainActivity.SHOW_STARS, showMask, fg, onShow)
        ShowRow("Satellites", MainActivity.SHOW_SATELLITES, showMask, fg, onShow)
        SettingRow("Text size: $textSizeText", fg, onTextSize)
        SettingRow("Screen idle: $idleText", fg, onIdle)
        SettingRow("ISS alert 5 min: " + if (alertOn) "ON" else "OFF", fg, onAlert)
        SettingRow("Flip sky 180\u00B0: " + if (flipOn) "ON" else "OFF", fg, onFlip)
        SettingRow("Refresh satellites", fg, onRefresh)
        if (status.isNotEmpty()) {
            Text(
                text = status,
                color = fg.copy(alpha = 0.7f),
                fontSize = 10.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp)
            )
        }
    }
}

@Composable
fun ShowRow(label: String, bit: Int, mask: Int, fg: Color, onShow: (Int) -> Unit) {
    val on = mask and bit != 0
    Text(
        text = (if (on) "[x] " else "[  ] ") + label,
        color = if (on) fg else fg.copy(alpha = 0.5f),
        fontSize = 14.sp,
        textAlign = TextAlign.Center,
        modifier = Modifier.clickable { onShow(bit) }.padding(horizontal = 12.dp, vertical = 6.dp)
    )
}

@Composable
fun SettingRow(text: String, fg: Color, onClick: () -> Unit) {
    Text(
        text = text,
        color = fg,
        fontSize = 14.sp,
        textAlign = TextAlign.Center,
        modifier = Modifier.clickable { onClick() }.padding(horizontal = 12.dp, vertical = 7.dp)
    )
}

@Composable
fun PlanetPage(name: String, location: Location?, nowMs: Long, fg: Color) {
    Column(
        modifier = Modifier.fillMaxSize().padding(top = 14.dp, bottom = 10.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val phase = if (name == "Moon") remember(nowMs / 60000L) { Astro.moonPhase(nowMs) } else null
        PlanetArt(name = name, modifier = Modifier.size(64.dp), moonPhaseAngle = phase?.angle)
        Text(text = name, color = fg, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        if (phase != null) {
            Text(
                text = "${phase.name} (${(phase.illumination * 100.0).toInt()}% lit)",
                color = fg,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
        }
        if (location == null) {
            Text(text = "Waiting for location...", color = fg.copy(alpha = 0.8f), fontSize = 12.sp)
        } else {
            val lat = location.latitude
            val lon = location.longitude
            val dayStart = startOfDay(nowMs)
            val events = remember(name, dayStart, lat, lon) { Astro.dayEvents(name, lat, lon, dayStart) }
            val now = Astro.horizontalOf(name, nowMs, lat, lon)
            val where = if (now.second > 0.0) {
                "Now ${now.second.toInt()}\u00B0 up, ${compassName(now.first)}"
            } else {
                "Below the horizon"
            }
            Text(text = where, color = fg.copy(alpha = 0.85f), fontSize = 12.sp)
            if (events.peakAlt < -0.8) {
                Text(text = "Does not rise today", color = fg, fontSize = 13.sp)
            } else {
                Text(
                    text = "Rise ${clock(events.riseMs)}   Set ${clock(events.setMs)}",
                    color = fg,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "Highest ${clock(events.peakMs)}  ${events.peakAlt.toInt()}\u00B0",
                    color = fg,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
