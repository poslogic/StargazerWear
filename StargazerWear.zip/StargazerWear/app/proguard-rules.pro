# Stargazer ProGuard rules (none needed yet)
