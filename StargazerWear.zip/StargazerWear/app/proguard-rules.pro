# Stargazer Wear OS ProGuard Rules

# Keep Complication Provider
-keep class com.burtbot.stargazer.StargazerComplicationProvider { *; }

# Keep Tile Service
-keep class com.burtbot.stargazer.StargazerTileService { *; }

# Keep MainActivity
-keep class com.burtbot.stargazer.MainActivity { *; }

# Keep ProtoLayout classes
-keep class androidx.wear.protolayout.** { *; }

# Keep Complication Data classes
-keep class androidx.wear.complications.data.** { *; }

# Keep Tile classes
-keep class androidx.wear.tiles.** { *; }

# Keep Kotlin coroutines
-keep class kotlinx.coroutines.** { *; }

# Keep ThreeTenBP
-keep class org.threeten.bp.** { *; }